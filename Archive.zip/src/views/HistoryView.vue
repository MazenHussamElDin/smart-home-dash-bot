<template>
  <div class="thd-page">

    <!-- ── Page header ─────────────────────────────── -->
    <div class="thd-page-header">
      <div class="container-fluid px-4">
        <div class="thd-section-label">DATENANALYSE</div>
        <h1 class="thd-page-title mb-0">VERLAUFSDIAGRAMME</h1>
      </div>
    </div>

    <div class="container-fluid px-4 py-4">

      <!-- ── Filter bar ───────────────────────────────── -->
      <div class="thd-filter-bar mb-4">
        <!-- Sensor selector -->
        <div class="thd-filter-group">
          <label class="thd-filter-label">SENSOR</label>
          <select v-model="selectedSensorId" class="thd-select" @change="fetchData">
            <option value="">Alle Sensoren</option>
            <option
              v-for="s in availableSensors"
              :key="s.sensorId"
              :value="s.sensorId"
            >
              {{ s.sensorName }}
            </option>
          </select>
        </div>

        <!-- Time range -->
        <div class="thd-filter-group">
          <label class="thd-filter-label">ZEITRAUM</label>
          <div class="thd-range-btns">
            <button
              v-for="r in ranges"
              :key="r.hours"
              class="thd-range-btn"
              :class="{ active: selectedHours === r.hours }"
              @click="selectRange(r.hours)"
            >
              {{ r.label }}
            </button>
          </div>
        </div>

        <!-- Refresh -->
        <div class="thd-filter-group thd-filter-action">
          <button class="btn-thd" @click="fetchData" :disabled="loading">
            <span v-if="loading" class="thd-spinner-sm-inline"></span>
            {{ loading ? 'Lädt…' : 'Aktualisieren' }}
          </button>
        </div>
      </div>

      <!-- ── Stats row ────────────────────────────────── -->
      <div v-if="stats.length" class="row g-3 mb-4">
        <div
          v-for="s in stats"
          :key="s.sensorId + s.type"
          class="col-6 col-md-3"
        >
          <div class="thd-stat-card">
            <div class="thd-stat-card-name">{{ s.sensorName }}</div>
            <div class="thd-stat-card-type">{{ s.type }}</div>
            <div class="thd-stat-grid">
              <div class="thd-stat-item">
                <span class="thd-stat-item-label">MIN</span>
                <span class="thd-stat-item-value">{{ s.min }} <small>{{ s.unit }}</small></span>
              </div>
              <div class="thd-stat-item">
                <span class="thd-stat-item-label">MAX</span>
                <span class="thd-stat-item-value">{{ s.max }} <small>{{ s.unit }}</small></span>
              </div>
              <div class="thd-stat-item thd-stat-item--avg">
                <span class="thd-stat-item-label">Ø AVG</span>
                <span class="thd-stat-item-value thd-stat-avg">{{ s.avg }} <small>{{ s.unit }}</small></span>
              </div>
              <div class="thd-stat-item">
                <span class="thd-stat-item-label">MESSGN.</span>
                <span class="thd-stat-item-value">{{ s.count }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ── Chart ────────────────────────────────────── -->
      <div class="thd-section-label">VERLAUF</div>
      <div class="thd-chart-card mb-4">

        <!-- Empty state -->
        <div v-if="!loading && !hasData" class="thd-no-data">
          <svg width="36" height="36" viewBox="0 0 24 24" fill="currentColor" style="color: var(--thd-border)">
            <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 14l-5-5 1.41-1.41L12 14.17l7.59-7.59L21 8l-9 9z"/>
          </svg>
          <p>Keine Daten für den gewählten Zeitraum</p>
          <span>Versuchen Sie einen anderen Sensor oder Zeitraum, oder führen Sie <code>npm run seed</code> aus.</span>
        </div>

        <!-- Loading -->
        <div v-else-if="loading" class="thd-chart-loading">
          <div class="thd-spinner-md"></div>
        </div>

        <!-- Chart canvas -->
        <div v-show="!loading && hasData" class="thd-chart-wrap">
          <canvas ref="chartCanvas"></canvas>
        </div>
      </div>

    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted, watch, nextTick } from 'vue'
import {
  Chart,
  LineController,
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js'
import { sensorsApi, type SensorReading, type SensorStats } from '@/api/sensors'

Chart.register(
  LineController,
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Title,
  Tooltip,
  Legend,
  Filler,
)

// ── State ──────────────────────────────────────────────
const chartCanvas = ref<HTMLCanvasElement | null>(null)
let chartInstance: Chart | null = null

const loading = ref(false)
const readings = ref<SensorReading[]>([])
const stats = ref<SensorStats[]>([])
const availableSensors = ref<{ sensorId: string; sensorName: string }[]>([])

const selectedSensorId = ref('')
const selectedHours = ref(24)

const ranges = [
  { label: '6h',  hours: 6  },
  { label: '24h', hours: 24 },
  { label: '48h', hours: 48 },
]

// ── Computed ───────────────────────────────────────────
const hasData = computed(() => readings.value.length > 0)

// ── Chart colours per sensor ───────────────────────────
const palette = [
  '#29abe2', '#3daa5c', '#f59e0b', '#e05252', '#8b5cf6',
]

// ── Init chart ─────────────────────────────────────────
function initChart() {
  if (!chartCanvas.value) return

  chartInstance = new Chart(chartCanvas.value, {
    type: 'line',
    data: { labels: [], datasets: [] },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      scales: {
        x: {
          ticks: {
            maxTicksLimit: 12,
            maxRotation: 0,
            font: { size: 11, family: 'Inter, sans-serif' },
            color: '#888',
          },
          grid: { color: 'rgba(0,0,0,0.04)' },
        },
        y: {
          ticks: {
            font: { size: 11, family: 'Inter, sans-serif' },
            color: '#888',
          },
          grid: { color: 'rgba(0,0,0,0.06)' },
        },
      },
      plugins: {
        legend: {
          display: true,
          position: 'top',
          labels: {
            font: { size: 11, family: 'Inter, sans-serif' },
            color: '#555',
            boxWidth: 12,
            padding: 16,
          },
        },
        tooltip: {
          backgroundColor: '#1c2a3a',
          titleFont: { size: 11, family: 'Inter, sans-serif' },
          bodyFont: { size: 12, family: 'Inter, sans-serif' },
          padding: 10,
          cornerRadius: 4,
        },
      },
    },
  })
}

// ── Build chart datasets from readings ─────────────────
function buildChart() {
  if (!chartInstance || !readings.value.length) return

  // Group readings by sensorId, sorted oldest → newest
  const grouped: Record<string, SensorReading[]> = {}
  for (const r of [...readings.value].sort(
    (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
  )) {
    if (!grouped[r.sensorId]) grouped[r.sensorId] = []
    grouped[r.sensorId].push(r)
  }

  // Build a unified time label axis from the most-sampled sensor
  const allTimes = [...new Set(
    readings.value.map(r =>
      new Date(r.timestamp).toLocaleString('de-DE', {
        month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit',
      })
    )
  )].sort()

  // Downsample if too many points (keep chart readable)
  const maxLabels = 60
  const step = Math.ceil(allTimes.length / maxLabels)
  const labels = allTimes.filter((_, i) => i % step === 0)

  // Datasets
  const datasets = Object.entries(grouped).map(([, sReadings], idx) => {
    const color = palette[idx % palette.length]
    const name = sReadings[0].sensorName
    const unit = sReadings[0].unit

    // Map each label to nearest reading value
    const data = labels.map(label => {
      const match = sReadings.find(r =>
        new Date(r.timestamp).toLocaleString('de-DE', {
          month: '2-digit', day: '2-digit',
          hour: '2-digit', minute: '2-digit',
        }) === label
      )
      return match ? match.value : null
    })

    return {
      label: `${name} (${unit})`,
      data,
      borderColor: color,
      backgroundColor: color + '14',
      borderWidth: 2,
      pointRadius: labels.length > 30 ? 0 : 3,
      tension: 0.3,
      fill: false,
      spanGaps: true,
    }
  })

  chartInstance.data.labels = labels
  chartInstance.data.datasets = datasets
  chartInstance.update()
}

// ── Fetch data ─────────────────────────────────────────
async function fetchData() {
  loading.value = true
  readings.value = []
  stats.value = []

  try {
    const from = new Date(Date.now() - selectedHours.value * 60 * 60 * 1000).toISOString()

    const [readingsRes, statsRes] = await Promise.all([
      sensorsApi.getReadings({
        sensorId: selectedSensorId.value || undefined,
        from,
        limit: 500,
      }),
      sensorsApi.getStats(selectedHours.value, selectedSensorId.value || undefined),
    ])

    readings.value = readingsRes
    stats.value = statsRes

    await nextTick()
    buildChart()
  } catch {
    readings.value = []
    stats.value = []
  } finally {
    loading.value = false
  }
}

// ── Load available sensors for the selector ────────────
async function loadSensors() {
  try {
    const latest = await sensorsApi.getLatest()
    availableSensors.value = latest.map(r => ({
      sensorId: r.sensorId,
      sensorName: r.sensorName,
    }))
  } catch {
    availableSensors.value = []
  }
}

function selectRange(hours: number) {
  selectedHours.value = hours
  fetchData()
}

// Re-build chart if canvas appears after v-show toggle
watch(hasData, async (val) => {
  if (val) {
    await nextTick()
    buildChart()
  }
})

// ── Lifecycle ──────────────────────────────────────────
onMounted(async () => {
  await nextTick()
  initChart()
  await loadSensors()
  await fetchData()
})

onUnmounted(() => {
  chartInstance?.destroy()
})
</script>

<style scoped>
/* ── Page ─────────────────────────────────────────────── */
.thd-page {
  background: var(--thd-page);
  min-height: 100vh;
}

/* ── Page header ─────────────────────────────────────── */
.thd-page-header {
  background: var(--thd-white);
  border-bottom: 1px solid var(--thd-border);
  padding: 1.75rem 0 1.5rem;
}
.thd-page-title {
  font-size: clamp(1rem, 2.5vw, 1.4rem);
  font-weight: 300;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  color: var(--thd-text);
}
.thd-section-label {
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--thd-muted);
  margin-bottom: 0.75rem;
}

/* ── Filter bar ──────────────────────────────────────── */
.thd-filter-bar {
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  padding: 1rem 1.25rem;
  display: flex;
  align-items: flex-end;
  gap: 1.5rem;
  flex-wrap: wrap;
}

.thd-filter-group {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
}

.thd-filter-label {
  font-size: 0.65rem;
  font-weight: 700;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--thd-muted);
}

.thd-select {
  padding: 0.45rem 0.75rem;
  font-size: 0.85rem;
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  background: var(--thd-white);
  color: var(--thd-text);
  outline: none;
  min-width: 200px;
  cursor: pointer;
  transition: border-color 0.15s;
}
.thd-select:focus {
  border-color: var(--thd-cyan);
}

.thd-range-btns {
  display: flex;
  gap: 0;
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  overflow: hidden;
}

.thd-range-btn {
  background: var(--thd-white);
  border: none;
  border-right: 1px solid var(--thd-border);
  color: var(--thd-muted);
  font-size: 0.78rem;
  font-weight: 600;
  padding: 0.42rem 0.85rem;
  cursor: pointer;
  transition: background 0.15s, color 0.15s;
  letter-spacing: 0.04em;
}
.thd-range-btn:last-child { border-right: none; }
.thd-range-btn:hover { background: var(--thd-page); color: var(--thd-text); }
.thd-range-btn.active {
  background: var(--thd-cyan);
  color: #fff;
}

.thd-filter-action { margin-left: auto; }

.btn-thd {
  background: var(--thd-cyan);
  border: none;
  color: #fff;
  font-size: 0.82rem;
  font-weight: 600;
  padding: 0.45rem 1.1rem;
  border-radius: 3px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.4rem;
  transition: background 0.15s;
  letter-spacing: 0.03em;
}
.btn-thd:hover:not(:disabled) { background: var(--thd-cyan-dark); }
.btn-thd:disabled { opacity: 0.65; cursor: not-allowed; }

/* ── Stats cards ─────────────────────────────────────── */
.thd-stat-card {
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  padding: 1rem 1.1rem;
}
.thd-stat-card-name {
  font-size: 0.8rem;
  font-weight: 600;
  color: var(--thd-text);
  margin-bottom: 0.1rem;
}
.thd-stat-card-type {
  font-size: 0.65rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--thd-cyan);
  margin-bottom: 0.75rem;
}
.thd-stat-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.5rem;
}
.thd-stat-item {
  display: flex;
  flex-direction: column;
  gap: 0.1rem;
}
.thd-stat-item--avg {
  grid-column: span 2;
  border-top: 1px solid var(--thd-border-light);
  padding-top: 0.4rem;
  margin-top: 0.1rem;
}
.thd-stat-item-label {
  font-size: 0.6rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--thd-muted);
}
.thd-stat-item-value {
  font-size: 1rem;
  font-weight: 500;
  color: var(--thd-text);
  line-height: 1.2;
}
.thd-stat-item-value small {
  font-size: 0.7rem;
  font-weight: 400;
  color: var(--thd-muted);
}
.thd-stat-avg {
  font-size: 1.2rem;
  font-weight: 300;
  color: var(--thd-cyan);
}

/* ── Chart card ──────────────────────────────────────── */
.thd-chart-card {
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  overflow: hidden;
}

.thd-chart-wrap {
  padding: 1.25rem 1rem 1rem;
  height: 340px;
  position: relative;
}

.thd-chart-loading {
  height: 340px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.thd-no-data {
  height: 300px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  color: var(--thd-muted);
  text-align: center;
  padding: 2rem;
}
.thd-no-data p {
  font-size: 0.95rem;
  font-weight: 500;
  margin: 0;
  color: var(--thd-text);
}
.thd-no-data span {
  font-size: 0.8rem;
  color: var(--thd-muted);
}
.thd-no-data code {
  font-size: 0.78rem;
  background: var(--thd-page);
  padding: 0.1em 0.4em;
  border-radius: 3px;
  border: 1px solid var(--thd-border);
}

/* ── Spinners ─────────────────────────────────────────── */
.thd-spinner-sm-inline {
  display: inline-block;
  width: 12px;
  height: 12px;
  border: 2px solid rgba(255,255,255,0.4);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
.thd-spinner-md {
  width: 28px;
  height: 28px;
  border: 3px solid var(--thd-border);
  border-top-color: var(--thd-cyan);
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
</style>
