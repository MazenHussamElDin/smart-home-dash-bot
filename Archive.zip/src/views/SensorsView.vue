<template>
  <div class="thd-page">

    <!-- ── Page header ─────────────────────────────── -->
    <div class="thd-page-header">
      <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
          <div>
            <div class="thd-section-label">LIVE MONITORING</div>
            <h1 class="thd-page-title mb-0">SENSOR ÜBERSICHT</h1>
          </div>
          <div class="d-flex align-items-center gap-3">
            <!-- Polling indicator -->
            <div class="thd-poll-status" :class="{ active: polling }">
              <span class="thd-poll-dot"></span>
              <span class="thd-poll-label">{{ polling ? 'Live' : 'Pausiert' }}</span>
            </div>
            <!-- Pause / Resume -->
            <button class="btn-thd-outline" @click="togglePolling">
              {{ polling ? 'Pause' : 'Fortsetzen' }}
            </button>
          </div>
        </div>
      </div>
    </div>

    <div class="container-fluid px-4 py-4">

      <!-- ── System sensor cards (real data) ─────────── -->
      <div class="thd-section-label">SYSTEM — ECHTZEIT</div>
      <div class="row g-3 mb-4">
        <div
          v-for="reading in systemReadings"
          :key="reading.sensorId"
          class="col-6 col-md-4 col-lg-2-4"
        >
          <div class="thd-sensor-card" :class="getSensorCardClass(reading)">
            <div class="thd-sensor-card-label">{{ reading.sensorName }}</div>
            <div class="thd-sensor-card-value">
              {{ reading.value }}
              <span class="thd-sensor-card-unit">{{ reading.unit }}</span>
            </div>
            <div class="thd-sensor-card-type">{{ reading.type }}</div>
          </div>
        </div>
        <div v-if="!systemReadings.length" class="col-12">
          <div class="thd-empty-state">Keine Systemdaten verfügbar</div>
        </div>
      </div>

      <!-- ── Dynamic chart ────────────────────────────── -->
      <div class="thd-section-label">DYNAMISCHER VERLAUF — LETZTE 60 SEKUNDEN</div>
      <div class="thd-chart-card mb-4">
        <div class="thd-chart-toolbar">
          <div class="d-flex gap-2 flex-wrap">
            <button
              v-for="metric in chartMetrics"
              :key="metric.key"
              class="thd-metric-btn"
              :class="{ active: activeMetric === metric.key }"
              @click="activeMetric = metric.key"
            >
              {{ metric.label }}
            </button>
          </div>
          <span class="thd-chart-info">Aktualisierung alle {{ pollInterval / 1000 }}s</span>
        </div>
        <div class="thd-chart-wrap">
          <canvas ref="chartCanvas"></canvas>
        </div>
      </div>

      <!-- ── IoT sensor cards (simulated) ────────────── -->
      <div class="thd-section-label">IOT SENSOREN — SIMULIERT</div>
      <div class="row g-3">
        <div
          v-for="reading in iotReadings"
          :key="reading.sensorId"
          class="col-12 col-sm-6 col-lg-3"
        >
          <div class="thd-iot-card">
            <div class="thd-iot-header">
              <span class="thd-iot-name">{{ reading.sensorName }}</span>
              <span class="thd-iot-type-badge">{{ reading.type }}</span>
            </div>
            <div class="thd-iot-value">
              {{ reading.value }}
              <span class="thd-iot-unit">{{ reading.unit }}</span>
            </div>
            <div class="thd-iot-bar-wrap">
              <div
                class="thd-iot-bar"
                :style="{ width: getIotPercent(reading) + '%' }"
                :class="getIotBarClass(reading)"
              ></div>
            </div>
            <div class="thd-iot-timestamp">
              {{ formatTime(reading.timestamp) }}
            </div>
          </div>
        </div>
        <div v-if="!iotReadings.length" class="col-12">
          <div class="thd-empty-state">Keine IoT-Sensordaten verfügbar</div>
        </div>
      </div>

    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch, nextTick } from 'vue'
import {
  Chart,
  LineController,
  LineElement,
  PointElement,
  LinearScale,
  TimeScale,
  CategoryScale,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js'
import { sensorsApi, type SystemReading, type SensorReading } from '@/api/sensors'

// Register Chart.js components
Chart.register(
  LineController,
  LineElement,
  PointElement,
  LinearScale,
  TimeScale,
  CategoryScale,
  Title,
  Tooltip,
  Legend,
  Filler,
)

// ── Config ─────────────────────────────────────────────
const pollInterval = 1500   // ms — poll every 1.5s
const maxDataPoints = 60    // keep last 60 readings

// ── State ──────────────────────────────────────────────
const polling = ref(true)
const systemReadings = ref<SystemReading[]>([])
const iotReadings = ref<SensorReading[]>([])
const chartCanvas = ref<HTMLCanvasElement | null>(null)
let chartInstance: Chart | null = null
let pollTimer: ReturnType<typeof setInterval> | null = null

// Chart metric selector
const activeMetric = ref('system-cpu-load')
const chartMetrics = [
  { key: 'system-cpu-load',  label: 'CPU Load %' },
  { key: 'system-memory',    label: 'Memory %' },
  { key: 'system-disk',      label: 'Disk %' },
  { key: 'system-cpu-temp',  label: 'CPU Temp °C' },
]

// Rolling history: sensorId → array of { label, value }
const history: Record<string, { labels: string[], values: number[] }> = {}

// ── Chart init ─────────────────────────────────────────
function initChart() {
  if (!chartCanvas.value) return

  chartInstance = new Chart(chartCanvas.value, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: '',
        data: [],
        borderColor: '#29abe2',
        backgroundColor: 'rgba(41,171,226,0.08)',
        borderWidth: 2,
        pointRadius: 0,
        tension: 0.3,
        fill: true,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 300 },
      scales: {
        x: {
          ticks: {
            maxTicksLimit: 10,
            font: { size: 11, family: 'Inter, sans-serif' },
            color: '#888',
          },
          grid: { color: 'rgba(0,0,0,0.04)' },
        },
        y: {
          ticks: {
            font: { size: 11, family: 'Inter, sans-serif' },
            color: '#888',
          },
          grid: { color: 'rgba(0,0,0,0.06)' },
        },
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1c2a3a',
          titleFont: { size: 11, family: 'Inter, sans-serif' },
          bodyFont: { size: 12, family: 'Inter, sans-serif' },
          padding: 10,
          cornerRadius: 4,
        },
      },
    },
  })
}

// ── Update chart with current metric ──────────────────
function updateChart() {
  if (!chartInstance) return

  const h = history[activeMetric.value]
  if (!h) return

  const metric = chartMetrics.find(m => m.key === activeMetric.value)
  chartInstance.data.labels = [...h.labels]
  chartInstance.data.datasets[0].data = [...h.values]
  chartInstance.data.datasets[0].label = metric?.label ?? ''
  chartInstance.update('none') // no animation for live updates
}

// ── Fetch system data ──────────────────────────────────
async function fetchSystemData() {
  try {
    const res = await sensorsApi.getSystemAll()
    systemReadings.value = res.readings

    const label = new Date().toLocaleTimeString('de-DE', {
      hour: '2-digit', minute: '2-digit', second: '2-digit'
    })

    for (const r of res.readings) {
      if (!history[r.sensorId]) {
        history[r.sensorId] = { labels: [], values: [] }
      }
      history[r.sensorId].labels.push(label)
      history[r.sensorId].values.push(r.value)

      // Keep rolling window
      if (history[r.sensorId].labels.length > maxDataPoints) {
        history[r.sensorId].labels.shift()
        history[r.sensorId].values.shift()
      }
    }

    updateChart()
  } catch {
    // silently keep last values
  }
}

// ── Fetch IoT sensor readings ──────────────────────────
async function fetchIotData() {
  try {
    iotReadings.value = await sensorsApi.getLatest()
  } catch {
    // keep last values
  }
}

// ── Polling control ────────────────────────────────────
function startPolling() {
  fetchSystemData()
  fetchIotData()
  pollTimer = setInterval(async () => {
    await fetchSystemData()
    // IoT data updates less frequently — every 5 polls
  }, pollInterval)
}

function stopPolling() {
  if (pollTimer) {
    clearInterval(pollTimer)
    pollTimer = null
  }
}

function togglePolling() {
  polling.value = !polling.value
  if (polling.value) startPolling()
  else stopPolling()
}

// Re-render chart when metric changes
watch(activeMetric, updateChart)

// ── Lifecycle ──────────────────────────────────────────
onMounted(async () => {
  await nextTick()
  initChart()
  startPolling()
})

onUnmounted(() => {
  stopPolling()
  chartInstance?.destroy()
})

// ── Helpers ────────────────────────────────────────────
function getSensorCardClass(r: SystemReading): string {
  if (r.type === 'load' || r.type === 'memory' || r.type === 'storage') {
    if (r.value > 90) return 'danger'
    if (r.value > 70) return 'warning'
  }
  return ''
}

// IoT percent for bar (rough normalization per type)
function getIotPercent(r: SensorReading): number {
  const ranges: Record<string, [number, number]> = {
    temperature: [16, 30],
    humidity:    [25, 75],
    co2:         [350, 1200],
    pressure:    [990, 1035],
    light:       [0, 1000],
  }
  const [min, max] = ranges[r.type] ?? [0, 100]
  return Math.round(((r.value - min) / (max - min)) * 100)
}

function getIotBarClass(r: SensorReading): string {
  const pct = getIotPercent(r)
  if (pct > 85) return 'bar-danger'
  if (pct > 65) return 'bar-warning'
  return 'bar-ok'
}

function formatTime(ts: string): string {
  return new Date(ts).toLocaleTimeString('de-DE', {
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  })
}
</script>

<style scoped>
/* ── Page shell ───────────────────────────────────────── */
.thd-page {
  background: var(--thd-page);
  min-height: 100vh;
}

/* ── Page header ─────────────────────────────────────── */
.thd-page-header {
  background: var(--thd-white);
  border-bottom: 1px solid var(--thd-border);
  padding: 1.75rem 0 1.5rem;
}

/* ── Poll status indicator ───────────────────────────── */
.thd-poll-status {
  display: flex;
  align-items: center;
  gap: 0.4rem;
}
.thd-poll-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--thd-muted);
  flex-shrink: 0;
}
.thd-poll-status.active .thd-poll-dot {
  background: #3daa5c;
  animation: pulse 1.5s ease-in-out infinite;
}
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50%       { opacity: 0.3; }
}
.thd-poll-label {
  font-size: 0.78rem;
  font-weight: 600;
  color: var(--thd-muted);
  letter-spacing: 0.05em;
  text-transform: uppercase;
}
.thd-poll-status.active .thd-poll-label {
  color: #3daa5c;
}

/* ── Section label ───────────────────────────────────── */
.thd-section-label {
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--thd-muted);
  margin-bottom: 0.75rem;
}

/* ── System sensor cards ─────────────────────────────── */
.col-lg-2-4 {
  flex: 0 0 auto;
  width: 20%;
}
@media (max-width: 991px) { .col-lg-2-4 { width: 33.333%; } }
@media (max-width: 575px) { .col-lg-2-4 { width: 50%; } }

.thd-sensor-card {
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  padding: 1rem;
  border-top: 3px solid var(--thd-border);
  transition: border-color 0.3s;
}
.thd-sensor-card.warning { border-top-color: #f59e0b; }
.thd-sensor-card.danger  { border-top-color: var(--thd-danger); }

.thd-sensor-card-label {
  font-size: 0.7rem;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--thd-muted);
  margin-bottom: 0.5rem;
}
.thd-sensor-card-value {
  font-size: 1.6rem;
  font-weight: 200;
  color: var(--thd-text);
  line-height: 1;
}
.thd-sensor-card-unit {
  font-size: 0.8rem;
  font-weight: 400;
  color: var(--thd-muted);
  margin-left: 2px;
}
.thd-sensor-card-type {
  font-size: 0.68rem;
  color: var(--thd-muted);
  margin-top: 0.35rem;
  text-transform: capitalize;
}

/* ── Chart card ──────────────────────────────────────── */
.thd-chart-card {
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  overflow: hidden;
}

.thd-chart-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 0.5rem;
  padding: 0.85rem 1rem;
  border-bottom: 1px solid var(--thd-border);
}

.thd-metric-btn {
  background: var(--thd-page);
  border: 1px solid var(--thd-border);
  color: var(--thd-muted);
  font-size: 0.75rem;
  font-weight: 600;
  padding: 0.3rem 0.75rem;
  border-radius: 3px;
  cursor: pointer;
  transition: all 0.15s;
  letter-spacing: 0.03em;
}
.thd-metric-btn:hover {
  border-color: var(--thd-cyan);
  color: var(--thd-cyan);
}
.thd-metric-btn.active {
  background: var(--thd-cyan);
  border-color: var(--thd-cyan);
  color: #fff;
}

.thd-chart-info {
  font-size: 0.72rem;
  color: var(--thd-muted);
}

.thd-chart-wrap {
  padding: 1rem 1rem 0.75rem;
  height: 280px;
  position: relative;
}

/* ── IoT sensor cards ────────────────────────────────── */
.thd-iot-card {
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  padding: 1rem 1.1rem;
}

.thd-iot-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 0.6rem;
}

.thd-iot-name {
  font-size: 0.78rem;
  font-weight: 600;
  color: var(--thd-text);
}

.thd-iot-type-badge {
  font-size: 0.62rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--thd-cyan);
  background: rgba(41,171,226,0.08);
  padding: 0.15em 0.5em;
  border-radius: 2px;
}

.thd-iot-value {
  font-size: 1.8rem;
  font-weight: 200;
  color: var(--thd-text);
  line-height: 1;
  margin-bottom: 0.6rem;
}
.thd-iot-unit {
  font-size: 0.85rem;
  font-weight: 400;
  color: var(--thd-muted);
}

.thd-iot-bar-wrap {
  height: 4px;
  background: var(--thd-border);
  border-radius: 2px;
  overflow: hidden;
  margin-bottom: 0.5rem;
}
.thd-iot-bar {
  height: 100%;
  border-radius: 2px;
  transition: width 0.4s ease;
  max-width: 100%;
}
.thd-iot-bar.bar-ok      { background: #3daa5c; }
.thd-iot-bar.bar-warning { background: #f59e0b; }
.thd-iot-bar.bar-danger  { background: var(--thd-danger); }

.thd-iot-timestamp {
  font-size: 0.68rem;
  color: var(--thd-muted);
}

/* ── Empty / button helpers ──────────────────────────── */
.thd-empty-state {
  padding: 2rem;
  text-align: center;
  font-size: 0.85rem;
  color: var(--thd-muted);
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 3px;
}

.btn-thd-outline {
  background: transparent;
  border: 1px solid var(--thd-cyan);
  color: var(--thd-cyan);
  font-weight: 500;
  padding: 0.4rem 1rem;
  border-radius: 3px;
  cursor: pointer;
  font-size: 0.82rem;
  transition: background 0.15s, color 0.15s;
  letter-spacing: 0.03em;
}
.btn-thd-outline:hover {
  background: var(--thd-cyan);
  color: #fff;
}

.thd-page-title {
  font-size: clamp(1rem, 2.5vw, 1.4rem);
  font-weight: 300;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  color: var(--thd-text);
}
</style>
