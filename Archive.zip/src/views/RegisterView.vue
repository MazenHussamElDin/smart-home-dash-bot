<template>
  <div class="thd-login-page">
    <div class="thd-bg-overlay"></div>

    <div class="thd-login-card">

      <!-- Avatar icon -->
      <div class="thd-avatar">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="#fff">
          <path d="M15 12c2.2 0 4-1.8 4-4s-1.8-4-4-4-4 1.8-4 4 1.8 4 4 4zm-8 0c2.2 0 4-1.8 4-4S9.2 4 7 4 3 5.8 3 8s1.8 4 4 4zm0 2c-2.7 0-8 1.3-8 4v2h16v-2c0-2.7-5.3-4-8-4zm8 0c-.3 0-.7 0-1 .1 1.2.8 2 2 2 3.9v2h6v-2c0-2.7-5.3-4-7-4z"/>
        </svg>
      </div>

      <p class="thd-card-title">Konto erstellen</p>

      <!-- Error -->
      <div v-if="auth.error" class="thd-error">
        {{ auth.error }}
        <button class="thd-error-close" @click="auth.clearError()">✕</button>
      </div>

      <!-- Form -->
      <form @submit.prevent="handleSubmit" novalidate>
        <div class="thd-field">
          <input
            id="username"
            v-model.trim="form.username"
            type="text"
            class="thd-input"
            :class="{ 'thd-input--error': errors.username }"
            placeholder="Benutzername"
            autocomplete="username"
            :disabled="auth.loading"
          />
          <span v-if="errors.username" class="thd-field-error">{{ errors.username }}</span>
        </div>

        <div class="thd-field">
          <input
            id="email"
            v-model.trim="form.email"
            type="email"
            class="thd-input"
            :class="{ 'thd-input--error': errors.email }"
            placeholder="E-Mail-Adresse"
            autocomplete="email"
            :disabled="auth.loading"
          />
          <span v-if="errors.email" class="thd-field-error">{{ errors.email }}</span>
        </div>

        <div class="thd-field">
          <input
            id="password"
            v-model="form.password"
            type="password"
            class="thd-input"
            :class="{ 'thd-input--error': errors.password }"
            placeholder="Passwort (min. 6 Zeichen)"
            autocomplete="new-password"
            :disabled="auth.loading"
          />
          <span v-if="errors.password" class="thd-field-error">{{ errors.password }}</span>
        </div>

        <div class="thd-field">
          <input
            id="confirm"
            v-model="form.confirm"
            type="password"
            class="thd-input"
            :class="{ 'thd-input--error': errors.confirm }"
            placeholder="Passwort bestätigen"
            autocomplete="new-password"
            :disabled="auth.loading"
          />
          <span v-if="errors.confirm" class="thd-field-error">{{ errors.confirm }}</span>
        </div>

        <button type="submit" class="thd-login-btn" :disabled="auth.loading">
          <span v-if="auth.loading" class="thd-spinner"></span>
          {{ auth.loading ? '…' : 'Registrieren' }}
        </button>
      </form>

      <p class="thd-register-link">
        <router-link to="/login">← Zurück zum Login</router-link>
      </p>
    </div>

    <div class="thd-back-link">
      <span>Smart Home Dashboard</span>
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/stores_auth'

const router = useRouter()
const auth = useAuthStore()

const form = reactive({ username: '', email: '', password: '', confirm: '' })
const errors = reactive({ username: '', email: '', password: '', confirm: '' })

function validate(): boolean {
  errors.username = ''
  errors.email = ''
  errors.password = ''
  errors.confirm = ''
  let valid = true

  if (!form.username) {
    errors.username = 'Benutzername ist erforderlich'
    valid = false
  } else if (form.username.length < 3) {
    errors.username = 'Mindestens 3 Zeichen'
    valid = false
  }

  if (!form.email) {
    errors.email = 'E-Mail ist erforderlich'
    valid = false
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
    errors.email = 'Ungültige E-Mail-Adresse'
    valid = false
  }

  if (!form.password) {
    errors.password = 'Passwort ist erforderlich'
    valid = false
  } else if (form.password.length < 6) {
    errors.password = 'Mindestens 6 Zeichen'
    valid = false
  }

  if (!form.confirm) {
    errors.confirm = 'Bitte Passwort bestätigen'
    valid = false
  } else if (form.password !== form.confirm) {
    errors.confirm = 'Passwörter stimmen nicht überein'
    valid = false
  }

  return valid
}

async function handleSubmit() {
  auth.clearError()
  if (!validate()) return
  try {
    await auth.register(form.username, form.email, form.password)
    router.push('/dashboard')
  } catch {
    // error shown via store
  }
}
</script>

<style scoped>
.thd-login-page {
  position: relative;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-image:
    url('https://www.th-deg.de/images/campus.jpg'),
    linear-gradient(135deg, #2d4a6b 0%, #1a2f45 40%, #3d5a3e 100%);
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}
.thd-bg-overlay {
  position: absolute;
  inset: 0;
  background: rgba(20, 30, 48, 0.35);
  pointer-events: none;
}
.thd-login-card {
  position: relative;
  z-index: 1;
  background: #fff;
  border-radius: 12px;
  padding: 2.25rem 2.25rem 2rem;
  width: 100%;
  max-width: 380px;
  margin: 1rem;
  box-shadow: 0 8px 32px rgba(0,0,0,0.18);
  display: flex;
  flex-direction: column;
  align-items: center;
}
.thd-avatar {
  width: 58px;
  height: 58px;
  border-radius: 50%;
  background: #29abe2;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 0.75rem;
  box-shadow: 0 2px 8px rgba(41,171,226,0.35);
}
.thd-card-title {
  font-size: 0.95rem;
  font-weight: 600;
  color: #444;
  margin: 0 0 1.25rem;
}
.thd-error {
  width: 100%;
  background: #fef2f2;
  border: 1px solid #fca5a5;
  color: #b91c1c;
  border-radius: 6px;
  padding: 0.5rem 0.75rem;
  font-size: 0.82rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}
.thd-error-close {
  background: none;
  border: none;
  color: #b91c1c;
  cursor: pointer;
  font-size: 0.75rem;
  padding: 0;
}
.thd-field {
  width: 100%;
  margin-bottom: 0.85rem;
}
.thd-input {
  width: 100%;
  padding: 0.7rem 1rem;
  font-size: 0.9rem;
  background: #f2f3f5;
  border: 1.5px solid transparent;
  border-radius: 6px;
  color: #333;
  outline: none;
  transition: border-color 0.15s, background 0.15s;
}
.thd-input::placeholder { color: #aaa; }
.thd-input:focus {
  background: #fff;
  border-color: #29abe2;
  box-shadow: 0 0 0 3px rgba(41,171,226,0.15);
}
.thd-input--error { border-color: #dc3545; }
.thd-input:disabled { opacity: 0.65; }
.thd-field-error {
  display: block;
  font-size: 0.75rem;
  color: #dc3545;
  margin-top: 0.25rem;
  padding-left: 0.25rem;
}
.thd-login-btn {
  width: 100%;
  padding: 0.75rem;
  margin-top: 0.5rem;
  background: #29abe2;
  color: #fff;
  border: none;
  border-radius: 6px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  transition: background 0.15s;
}
.thd-login-btn:hover:not(:disabled) { background: #1a95cc; }
.thd-login-btn:disabled { opacity: 0.7; cursor: not-allowed; }
.thd-spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255,255,255,0.4);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
.thd-register-link {
  margin-top: 1.25rem;
  font-size: 0.8rem;
  color: #888;
  text-align: center;
}
.thd-register-link a {
  color: #29abe2;
  text-decoration: none;
  font-weight: 500;
}
.thd-register-link a:hover { text-decoration: underline; }
.thd-back-link {
  position: relative;
  z-index: 1;
  margin-top: 1.5rem;
  color: rgba(255,255,255,0.8);
  font-size: 0.85rem;
  font-weight: 500;
}
</style>
