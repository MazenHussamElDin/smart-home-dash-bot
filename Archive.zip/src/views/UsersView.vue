<template>
  <div class="thd-page">

    <!-- ── Page header ──────────────────────────────── -->
    <div class="thd-page-header">
      <div class="container-fluid px-4">
        <div class="thd-section-label">BENUTZERVERWALTUNG</div>
        <h1 class="thd-page-title mb-0">BENUTZER</h1>
      </div>
    </div>

    <div class="container-fluid px-4 py-4">

      <!-- ── Banners ───────────────────────────────────── -->
      <div v-if="banner.message" class="thd-banner mb-3" :class="banner.type === 'success' ? 'thd-banner--success' : 'thd-banner--error'">
        {{ banner.message }}
        <button class="thd-banner-close" @click="banner.message = ''">✕</button>
      </div>

      <div class="row g-4">

        <!-- ── LEFT: Add user form ───────────────────── -->
        <div class="col-12 col-lg-4">
          <div class="thd-section-label">{{ editingId ? 'BENUTZER BEARBEITEN' : 'NEUER BENUTZER' }}</div>
          <div class="thd-form-card">

            <form @submit.prevent="handleSubmit" novalidate>

              <!-- First name -->
              <div class="thd-field-group">
                <label class="thd-field-label">VORNAME *</label>
                <input
                  v-model.trim="form.firstName"
                  type="text"
                  class="thd-input"
                  :class="{ 'thd-input--error': errors.firstName }"
                  placeholder="Max"
                  :disabled="submitting"
                />
                <span v-if="errors.firstName" class="thd-field-error">{{ errors.firstName }}</span>
              </div>

              <!-- Last name -->
              <div class="thd-field-group">
                <label class="thd-field-label">NACHNAME *</label>
                <input
                  v-model.trim="form.lastName"
                  type="text"
                  class="thd-input"
                  :class="{ 'thd-input--error': errors.lastName }"
                  placeholder="Mustermann"
                  :disabled="submitting"
                />
                <span v-if="errors.lastName" class="thd-field-error">{{ errors.lastName }}</span>
              </div>

              <!-- Email -->
              <div class="thd-field-group">
                <label class="thd-field-label">E-MAIL *</label>
                <input
                  v-model.trim="form.email"
                  type="email"
                  class="thd-input"
                  :class="{ 'thd-input--error': errors.email }"
                  placeholder="max@example.com"
                  :disabled="submitting"
                />
                <span v-if="errors.email" class="thd-field-error">{{ errors.email }}</span>
              </div>

              <!-- Role -->
              <div class="thd-field-group">
                <label class="thd-field-label">ROLLE</label>
                <select
                  v-model="form.role"
                  class="thd-select"
                  :disabled="submitting"
                >
                  <option value="viewer">Viewer</option>
                  <option value="editor">Editor</option>
                  <option value="admin">Admin</option>
                </select>
              </div>

              <!-- Department -->
              <div class="thd-field-group">
                <label class="thd-field-label">ABTEILUNG</label>
                <input
                  v-model.trim="form.department"
                  type="text"
                  class="thd-input"
                  placeholder="Computer Science"
                  :disabled="submitting"
                />
              </div>

              <!-- Notes -->
              <div class="thd-field-group">
                <label class="thd-field-label">NOTIZEN</label>
                <textarea
                  v-model.trim="form.notes"
                  class="thd-textarea"
                  rows="2"
                  placeholder="Optionale Notizen…"
                  :disabled="submitting"
                ></textarea>
              </div>

              <!-- Buttons -->
              <div class="thd-form-actions">
                <button type="submit" class="btn-thd" :disabled="submitting">
                  <span v-if="submitting" class="thd-spinner-sm-inline"></span>
                  {{ submitting ? 'Speichert…' : editingId ? 'Aktualisieren' : 'Hinzufügen' }}
                </button>
                <button
                  v-if="editingId"
                  type="button"
                  class="btn-thd-outline"
                  @click="cancelEdit"
                  :disabled="submitting"
                >
                  Abbrechen
                </button>
              </div>

            </form>
          </div>
        </div>

        <!-- ── RIGHT: User table ─────────────────────── -->
        <div class="col-12 col-lg-8">
          <div class="d-flex align-items-center justify-content-between mb-2 flex-wrap gap-2">
            <div class="thd-section-label mb-0">ALLE BENUTZER ({{ users.length }})</div>
            <!-- Search -->
            <div class="thd-search-wrap">
              <input
                v-model.trim="search"
                type="text"
                class="thd-search-input"
                placeholder="Suchen…"
              />
            </div>
          </div>

          <!-- Loading -->
          <div v-if="loading" class="thd-table-card">
            <div class="thd-card-loading">
              <div class="thd-spinner-md"></div>
            </div>
          </div>

          <!-- Empty -->
          <div v-else-if="!filteredUsers.length" class="thd-table-card thd-empty-state">
            {{ search ? 'Keine Treffer für "' + search + '"' : 'Noch keine Benutzer vorhanden.' }}
          </div>

          <!-- Table -->
          <div v-else class="thd-table-card">
            <div class="thd-table-wrap">
              <table class="thd-table">
                <thead>
                  <tr>
                    <th>NAME</th>
                    <th>E-MAIL</th>
                    <th>ROLLE</th>
                    <th>ABTEILUNG</th>
                    <th>ERSTELLT</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <tr
                    v-for="user in filteredUsers"
                    :key="user._id"
                    :class="{ 'thd-row--editing': editingId === user._id }"
                  >
                    <td class="thd-td-name">
                      <span class="thd-user-avatar">{{ initials(user) }}</span>
                      {{ user.firstName }} {{ user.lastName }}
                    </td>
                    <td class="thd-td-email">{{ user.email }}</td>
                    <td>
                      <span class="thd-role-badge" :class="'role-' + user.role">{{ user.role }}</span>
                    </td>
                    <td class="thd-td-dept">{{ user.department || '—' }}</td>
                    <td class="thd-td-date">{{ formatDate(user.createdAt) }}</td>
                    <td class="thd-td-actions">
                      <button class="thd-action-btn thd-action-btn--edit" @click="startEdit(user)" title="Bearbeiten">
                        ✎
                      </button>
                      <button class="thd-action-btn thd-action-btn--delete" @click="confirmDelete(user._id)" title="Löschen">
                        ✕
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── Delete confirm modal ──────────────────────── -->
    <div v-if="deleteId" class="thd-modal-overlay" @click.self="deleteId = ''">
      <div class="thd-modal">
        <div class="thd-modal-title">Benutzer löschen?</div>
        <p class="thd-modal-body">Diese Aktion kann nicht rückgängig gemacht werden.</p>
        <div class="thd-modal-actions">
          <button class="btn-thd-outline" @click="deleteId = ''">Abbrechen</button>
          <button class="btn-thd btn-thd--danger" @click="deleteUser" :disabled="deleting">
            <span v-if="deleting" class="thd-spinner-sm-inline"></span>
            {{ deleting ? '…' : 'Löschen' }}
          </button>
        </div>
      </div>
    </div>

  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { usersApi, type User, type CreateUserPayload } from '@/api/users'

// ── State ──────────────────────────────────────────────
const users = ref<User[]>([])
const loading = ref(true)
const submitting = ref(false)
const deleting = ref(false)
const editingId = ref('')
const deleteId = ref('')
const search = ref('')

const banner = reactive({ message: '', type: 'success' as 'success' | 'error' })

const form = reactive<CreateUserPayload>({
  firstName: '',
  lastName: '',
  email: '',
  role: 'viewer',
  department: '',
  notes: '',
})

const errors = reactive({
  firstName: '',
  lastName: '',
  email: '',
})

// ── Computed ───────────────────────────────────────────
const filteredUsers = computed(() => {
  if (!search.value) return users.value
  const q = search.value.toLowerCase()
  return users.value.filter(u =>
    `${u.firstName} ${u.lastName} ${u.email} ${u.department}`.toLowerCase().includes(q)
  )
})

// ── Load users ─────────────────────────────────────────
async function loadUsers() {
  loading.value = true
  try {
    users.value = await usersApi.getAll()
  } catch {
    showBanner('Benutzer konnten nicht geladen werden.', 'error')
  } finally {
    loading.value = false
  }
}

// ── Validation ─────────────────────────────────────────
function validate(): boolean {
  errors.firstName = ''
  errors.lastName = ''
  errors.email = ''
  let valid = true

  if (!form.firstName.trim()) {
    errors.firstName = 'Vorname ist erforderlich'
    valid = false
  }

  if (!form.lastName.trim()) {
    errors.lastName = 'Nachname ist erforderlich'
    valid = false
  }

  if (!form.email.trim()) {
    errors.email = 'E-Mail ist erforderlich'
    valid = false
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
    errors.email = 'Ungültige E-Mail-Adresse'
    valid = false
  }

  return valid
}

// ── Submit (create or update) ──────────────────────────
async function handleSubmit() {
  if (!validate()) return

  submitting.value = true
  try {
    const payload: CreateUserPayload = {
      firstName: form.firstName.trim(),
      lastName: form.lastName.trim(),
      email: form.email.trim().toLowerCase(),
      role: form.role,
      department: form.department.trim(),
      notes: form.notes.trim(),
    }

    if (editingId.value) {
      const updated = await usersApi.update(editingId.value, payload)
      const idx = users.value.findIndex(u => u._id === editingId.value)
      if (idx !== -1) users.value[idx] = updated
      showBanner('Benutzer erfolgreich aktualisiert.', 'success')
      cancelEdit()
    } else {
      const created = await usersApi.create(payload)
      users.value.unshift(created)
      showBanner('Benutzer erfolgreich hinzugefügt.', 'success')
      resetForm()
    }
  } catch (err: unknown) {
    showBanner(err instanceof Error ? err.message : 'Speichern fehlgeschlagen.', 'error')
  } finally {
    submitting.value = false
  }
}

// ── Edit ───────────────────────────────────────────────
function startEdit(user: User) {
  editingId.value = user._id
  form.firstName = user.firstName
  form.lastName = user.lastName
  form.email = user.email
  form.role = user.role
  form.department = user.department
  form.notes = user.notes
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

function cancelEdit() {
  editingId.value = ''
  resetForm()
}

// ── Delete ─────────────────────────────────────────────
function confirmDelete(id: string) {
  deleteId.value = id
}

async function deleteUser() {
  deleting.value = true
  try {
    await usersApi.delete(deleteId.value)
    users.value = users.value.filter(u => u._id !== deleteId.value)
    showBanner('Benutzer gelöscht.', 'success')
    deleteId.value = ''
  } catch {
    showBanner('Löschen fehlgeschlagen.', 'error')
  } finally {
    deleting.value = false
  }
}

// ── Helpers ────────────────────────────────────────────
function resetForm() {
  form.firstName = ''
  form.lastName = ''
  form.email = ''
  form.role = 'viewer'
  form.department = ''
  form.notes = ''
  errors.firstName = ''
  errors.lastName = ''
  errors.email = ''
}

function showBanner(message: string, type: 'success' | 'error') {
  banner.message = message
  banner.type = type
  setTimeout(() => { banner.message = '' }, 4000)
}

function initials(user: User): string {
  return `${user.firstName[0] ?? ''}${user.lastName[0] ?? ''}`.toUpperCase()
}

function formatDate(ts: string): string {
  return new Date(ts).toLocaleDateString('de-DE', {
    day: '2-digit', month: '2-digit', year: 'numeric',
  })
}

onMounted(loadUsers)
</script>

<style scoped>
/* ── Page ─────────────────────────────────────────────── */
.thd-page {
  background: var(--thd-page);
  min-height: 100vh;
}
.thd-page-header {
  background: var(--thd-white);
  border-bottom: 1px solid var(--thd-border);
  padding: 1.75rem 0 1.5rem;
}
.thd-page-title {
  font-size: clamp(1rem, 2.5vw, 1.4rem);
  font-weight: 300;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  color: var(--thd-text);
}
.thd-section-label {
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--thd-muted);
  margin-bottom: 0.75rem;
}

/* ── Banners ─────────────────────────────────────────── */
.thd-banner {
  padding: 0.7rem 1rem;
  border-radius: 3px;
  font-size: 0.85rem;
  font-weight: 500;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.thd-banner--success { background: #ecfdf5; border: 1px solid #6ee7b7; color: #065f46; }
.thd-banner--error   { background: #fef2f2; border: 1px solid #fca5a5; color: #b91c1c; }
.thd-banner-close {
  background: none; border: none; cursor: pointer;
  color: inherit; font-size: 0.8rem; padding: 0; opacity: 0.7;
}
.thd-banner-close:hover { opacity: 1; }

/* ── Form card ───────────────────────────────────────── */
.thd-form-card {
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  padding: 1.25rem;
  display: flex;
  flex-direction: column;
  gap: 0;
}

/* ── Fields ──────────────────────────────────────────── */
.thd-field-group {
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
  margin-bottom: 0.85rem;
}
.thd-field-label {
  font-size: 0.62rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--thd-muted);
}
.thd-input,
.thd-select,
.thd-textarea {
  width: 100%;
  padding: 0.48rem 0.7rem;
  font-size: 0.875rem;
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  background: var(--thd-white);
  color: var(--thd-text);
  outline: none;
  font-family: inherit;
  transition: border-color 0.15s, box-shadow 0.15s;
}
.thd-input:focus,
.thd-select:focus,
.thd-textarea:focus {
  border-color: var(--thd-cyan);
  box-shadow: 0 0 0 3px rgba(41,171,226,0.1);
}
.thd-input--error { border-color: var(--thd-danger); }
.thd-input:disabled,
.thd-select:disabled,
.thd-textarea:disabled { opacity: 0.65; }
.thd-textarea { resize: vertical; min-height: 60px; }
.thd-field-error { font-size: 0.72rem; color: var(--thd-danger); }

/* ── Form actions ────────────────────────────────────── */
.thd-form-actions {
  display: flex;
  gap: 0.6rem;
  margin-top: 0.5rem;
}

/* ── Search ──────────────────────────────────────────── */
.thd-search-wrap { flex-shrink: 0; }
.thd-search-input {
  padding: 0.38rem 0.75rem;
  font-size: 0.82rem;
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  background: var(--thd-white);
  color: var(--thd-text);
  outline: none;
  width: 200px;
  transition: border-color 0.15s;
}
.thd-search-input:focus { border-color: var(--thd-cyan); }

/* ── Table card ──────────────────────────────────────── */
.thd-table-card {
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  overflow: hidden;
}
.thd-table-wrap { overflow-x: auto; }
.thd-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.82rem;
}
.thd-table thead tr {
  border-bottom: 2px solid var(--thd-border);
}
.thd-table th {
  padding: 0.65rem 1rem;
  font-size: 0.62rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--thd-muted);
  text-align: left;
  white-space: nowrap;
  background: var(--thd-page);
}
.thd-table td {
  padding: 0.7rem 1rem;
  border-bottom: 1px solid var(--thd-border-light);
  vertical-align: middle;
}
.thd-table tbody tr:last-child td { border-bottom: none; }
.thd-table tbody tr:hover { background: #fafafa; }
.thd-row--editing { background: rgba(41,171,226,0.04) !important; }

/* ── Table cell types ────────────────────────────────── */
.thd-td-name {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  font-weight: 500;
  white-space: nowrap;
}
.thd-user-avatar {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: var(--thd-cyan);
  color: #fff;
  font-size: 0.62rem;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.thd-td-email  { color: var(--thd-muted); font-size: 0.78rem; }
.thd-td-dept   { color: var(--thd-muted); font-size: 0.78rem; }
.thd-td-date   { color: var(--thd-muted); font-size: 0.75rem; white-space: nowrap; }
.thd-td-actions {
  display: flex;
  gap: 0.35rem;
  justify-content: flex-end;
}

/* ── Role badges ─────────────────────────────────────── */
.thd-role-badge {
  font-size: 0.62rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  padding: 0.2em 0.55em;
  border-radius: 2px;
}
.role-admin  { background: rgba(41,171,226,0.12); color: var(--thd-cyan); }
.role-editor { background: rgba(61,170,92,0.12);  color: #3daa5c; }
.role-viewer { background: var(--thd-page); color: var(--thd-muted); border: 1px solid var(--thd-border); }

/* ── Action buttons ──────────────────────────────────── */
.thd-action-btn {
  background: none;
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  width: 28px;
  height: 28px;
  font-size: 0.8rem;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background 0.15s, border-color 0.15s, color 0.15s;
  color: var(--thd-muted);
}
.thd-action-btn--edit:hover   { border-color: var(--thd-cyan); color: var(--thd-cyan); background: rgba(41,171,226,0.06); }
.thd-action-btn--delete:hover { border-color: var(--thd-danger); color: var(--thd-danger); background: rgba(220,53,69,0.06); }

/* ── Delete modal ────────────────────────────────────── */
.thd-modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.35);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
}
.thd-modal {
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 4px;
  padding: 1.75rem 2rem;
  max-width: 380px;
  width: 90%;
  box-shadow: 0 8px 32px rgba(0,0,0,0.12);
}
.thd-modal-title {
  font-size: 1rem;
  font-weight: 700;
  color: var(--thd-text);
  margin-bottom: 0.5rem;
}
.thd-modal-body {
  font-size: 0.85rem;
  color: var(--thd-muted);
  margin-bottom: 1.5rem;
}
.thd-modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 0.6rem;
}

/* ── Buttons ─────────────────────────────────────────── */
.btn-thd {
  background: var(--thd-cyan);
  border: none;
  color: #fff;
  font-size: 0.82rem;
  font-weight: 600;
  padding: 0.5rem 1.1rem;
  border-radius: 3px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.4rem;
  transition: background 0.15s;
  letter-spacing: 0.03em;
  font-family: inherit;
}
.btn-thd:hover:not(:disabled) { background: var(--thd-cyan-dark); }
.btn-thd:disabled { opacity: 0.65; cursor: not-allowed; }
.btn-thd--danger { background: var(--thd-danger); }
.btn-thd--danger:hover:not(:disabled) { background: #b91c1c; }

.btn-thd-outline {
  background: transparent;
  border: 1px solid var(--thd-border);
  color: var(--thd-text);
  font-size: 0.82rem;
  font-weight: 500;
  padding: 0.5rem 1.1rem;
  border-radius: 3px;
  cursor: pointer;
  transition: border-color 0.15s, color 0.15s;
  font-family: inherit;
}
.btn-thd-outline:hover:not(:disabled) { border-color: var(--thd-text); }
.btn-thd-outline:disabled { opacity: 0.65; cursor: not-allowed; }

/* ── Helpers ─────────────────────────────────────────── */
.thd-card-loading {
  padding: 3rem;
  display: flex;
  align-items: center;
  justify-content: center;
}
.thd-empty-state {
  padding: 2.5rem;
  text-align: center;
  font-size: 0.85rem;
  color: var(--thd-muted);
}
.thd-spinner-md {
  width: 28px; height: 28px;
  border: 3px solid var(--thd-border);
  border-top-color: var(--thd-cyan);
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
.thd-spinner-sm-inline {
  display: inline-block;
  width: 12px; height: 12px;
  border: 2px solid rgba(255,255,255,0.4);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
</style>
