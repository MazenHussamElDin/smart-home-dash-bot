<template>
  <div class="thd-login-page">

    <!-- Background: THD campus photo via CSS, overlay for readability -->
    <div class="thd-bg-overlay"></div>

    <!-- Floating card -->
    <div class="thd-login-card">

      <!-- Avatar icon -->
      <div class="thd-avatar">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="#fff">
          <path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"/>
        </svg>
      </div>

      <!-- Error message -->
      <div v-if="auth.error" class="thd-error">
        {{ auth.error }}
        <button class="thd-error-close" @click="auth.clearError()">✕</button>
      </div>

      <!-- Form -->
      <form @submit.prevent="handleSubmit" novalidate>
        <div class="thd-field">
          <input
            id="email"
            v-model.trim="form.email"
            type="email"
            class="thd-input"
            :class="{ 'thd-input--error': errors.email }"
            placeholder="Benutzername / E-Mail"
            autocomplete="email"
            :disabled="auth.loading"
          />
          <span v-if="errors.email" class="thd-field-error">{{ errors.email }}</span>
        </div>

        <div class="thd-field">
          <input
            id="password"
            v-model="form.password"
            type="password"
            class="thd-input"
            :class="{ 'thd-input--error': errors.password }"
            placeholder="Passwort"
            autocomplete="current-password"
            :disabled="auth.loading"
          />
          <span v-if="errors.password" class="thd-field-error">{{ errors.password }}</span>
        </div>

        <button type="submit" class="thd-login-btn" :disabled="auth.loading">
          <span v-if="auth.loading" class="thd-spinner"></span>
          {{ auth.loading ? '…' : 'Login' }}
        </button>
      </form>

      <!-- Register link -->
      <p class="thd-register-link">
        <router-link to="/register">Noch kein Konto? Registrieren</router-link>
      </p>
    </div>

    <!-- Bottom link like THD "Zurück zur Webseite" -->
    <div class="thd-back-link">
      <span>Smart Home Dashboard</span>
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/stores_auth'

const router = useRouter()
const auth = useAuthStore()

const form = reactive({ email: '', password: '' })
const errors = reactive({ email: '', password: '' })

function validate(): boolean {
  errors.email = ''
  errors.password = ''
  let valid = true

  if (!form.email) {
    errors.email = 'E-Mail ist erforderlich'
    valid = false
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
    errors.email = 'Ungültige E-Mail-Adresse'
    valid = false
  }

  if (!form.password) {
    errors.password = 'Passwort ist erforderlich'
    valid = false
  } else if (form.password.length < 6) {
    errors.password = 'Mindestens 6 Zeichen'
    valid = false
  }

  return valid
}

async function handleSubmit() {
  auth.clearError()
  if (!validate()) return
  try {
    await auth.login(form.email, form.password)
    router.push('/dashboard')
  } catch {
    // error shown via store
  }
}
</script>

<style scoped>
/* ── Full-screen campus background ───────────────────── */
.thd-login-page {
  position: relative;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  /* THD campus photo — using a matching architectural gradient as fallback */
  background-image:
    url('https://www.th-deg.de/images/campus.jpg'),
    linear-gradient(135deg, #2d4a6b 0%, #1a2f45 40%, #3d5a3e 100%);
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}

/* Subtle dark overlay for readability */
.thd-bg-overlay {
  position: absolute;
  inset: 0;
  background: rgba(20, 30, 48, 0.35);
  pointer-events: none;
}

/* ── Floating white card ─────────────────────────────── */
.thd-login-card {
  position: relative;
  z-index: 1;
  background: #fff;
  border-radius: 12px;
  padding: 2.5rem 2.25rem 2rem;
  width: 100%;
  max-width: 380px;
  margin: 1rem;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.18);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0;
}

/* ── Avatar circle ───────────────────────────────────── */
.thd-avatar {
  width: 58px;
  height: 58px;
  border-radius: 50%;
  background: #29abe2;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 1.5rem;
  box-shadow: 0 2px 8px rgba(41, 171, 226, 0.35);
}

/* ── Error banner ────────────────────────────────────── */
.thd-error {
  width: 100%;
  background: #fef2f2;
  border: 1px solid #fca5a5;
  color: #b91c1c;
  border-radius: 6px;
  padding: 0.5rem 0.75rem;
  font-size: 0.82rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}
.thd-error-close {
  background: none;
  border: none;
  color: #b91c1c;
  cursor: pointer;
  font-size: 0.75rem;
  padding: 0;
}

/* ── Form fields ─────────────────────────────────────── */
.thd-field {
  width: 100%;
  margin-bottom: 0.85rem;
}

.thd-input {
  width: 100%;
  padding: 0.7rem 1rem;
  font-size: 0.9rem;
  background: #f2f3f5;
  border: 1.5px solid transparent;
  border-radius: 6px;
  color: #333;
  outline: none;
  transition: border-color 0.15s, background 0.15s;
}
.thd-input::placeholder {
  color: #aaa;
}
.thd-input:focus {
  background: #fff;
  border-color: #29abe2;
  box-shadow: 0 0 0 3px rgba(41, 171, 226, 0.15);
}
.thd-input--error {
  border-color: #dc3545;
}
.thd-input:disabled {
  opacity: 0.65;
}
.thd-field-error {
  display: block;
  font-size: 0.75rem;
  color: #dc3545;
  margin-top: 0.25rem;
  padding-left: 0.25rem;
}

/* ── Login button ────────────────────────────────────── */
.thd-login-btn {
  width: 100%;
  padding: 0.75rem;
  margin-top: 0.5rem;
  background: #29abe2;
  color: #fff;
  border: none;
  border-radius: 6px;
  font-size: 1rem;
  font-weight: 600;
  letter-spacing: 0.02em;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  transition: background 0.15s;
}
.thd-login-btn:hover:not(:disabled) {
  background: #1a95cc;
}
.thd-login-btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
}

/* ── Spinner ─────────────────────────────────────────── */
.thd-spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255,255,255,0.4);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* ── Register link ───────────────────────────────────── */
.thd-register-link {
  margin-top: 1.25rem;
  font-size: 0.8rem;
  color: #888;
  text-align: center;
}
.thd-register-link a {
  color: #29abe2;
  text-decoration: none;
  font-weight: 500;
}
.thd-register-link a:hover {
  text-decoration: underline;
}

/* ── Bottom label ────────────────────────────────────── */
.thd-back-link {
  position: relative;
  z-index: 1;
  margin-top: 1.5rem;
  color: rgba(255,255,255,0.8);
  font-size: 0.85rem;
  font-weight: 500;
  letter-spacing: 0.02em;
}
</style>
