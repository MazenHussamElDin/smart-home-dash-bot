<template>
  <div class="thd-dashboard">

    <!-- ── Greeting bar ─────────────────────────────── -->
    <div class="thd-greeting-bar">
      <div class="container-fluid px-4">
        <h1 class="thd-greeting">
          HALLO {{ auth.username.toUpperCase() }}. SCHÖN, DASS DU DA BIST.
        </h1>
      </div>
    </div>

    <!-- ── Main content ─────────────────────────────── -->
    <div class="container-fluid px-4 py-4">

      <!-- Top row: Weather | Mensa | System -->
      <div class="thd-section-label">ÜBERSICHT</div>
      <div class="row g-3 mb-4">

        <!-- Weather card -->
        <div class="col-12 col-md-4">
          <div class="thd-info-card">
            <div class="thd-info-card-header">
              <span class="thd-card-icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M6.76 4.84l-1.8-1.79-1.41 1.41 1.79 1.79 1.42-1.41zM4 10.5H1v2h3v-2zm9-9.95h-2V3.5h2V.55zm7.45 3.91l-1.41-1.41-1.79 1.79 1.41 1.41 1.79-1.79zm-3.21 13.7l1.79 1.8 1.41-1.41-1.8-1.79-1.4 1.4zM20 10.5v2h3v-2h-3zm-8-5c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm-1 16.95h2V19.5h-2v2.95zm-7.45-3.91l1.41 1.41 1.79-1.8-1.41-1.41-1.79 1.8z"/>
                </svg>
              </span>
              <span class="thd-card-title">Wetter</span>
              <span v-if="weather?.mock" class="thd-mock-badge">demo</span>
            </div>
            <div v-if="weatherLoading" class="thd-card-loading">
              <div class="thd-spinner-sm"></div>
            </div>
            <div v-else-if="weather" class="thd-weather-body">
              <div class="thd-weather-temp">{{ weather.temperature }}°C</div>
              <div class="thd-weather-city">{{ weather.city }}</div>
              <div class="thd-weather-desc">{{ weather.description }}</div>
              <div class="thd-weather-meta">
                <span>Fühlt sich an wie {{ weather.feelsLike }}°C</span>
                <span>💧 {{ weather.humidity }}%</span>
                <span>🌬 {{ weather.windSpeed }} km/h</span>
              </div>
            </div>
            <div v-else class="thd-card-error">Wetterdaten nicht verfügbar</div>
          </div>
        </div>

        <!-- System info card -->
        <div class="col-12 col-md-4">
          <div class="thd-info-card">
            <div class="thd-info-card-header">
              <span class="thd-card-icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M20 18c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2H0v2h24v-2h-4zM4 6h16v10H4V6z"/>
                </svg>
              </span>
              <span class="thd-card-title">System</span>
              <span class="thd-live-dot"></span>
            </div>
            <div v-if="systemLoading" class="thd-card-loading">
              <div class="thd-spinner-sm"></div>
            </div>
            <div v-else-if="systemInfo" class="thd-system-body">
              <div class="thd-stat-row">
                <span class="thd-stat-label">CPU</span>
                <div class="thd-stat-bar-wrap">
                  <div class="thd-stat-bar" :style="{ width: systemInfo.cpu.currentLoad + '%' }"></div>
                </div>
                <span class="thd-stat-value">{{ systemInfo.cpu.currentLoad }}%</span>
              </div>
              <div class="thd-stat-row">
                <span class="thd-stat-label">RAM</span>
                <div class="thd-stat-bar-wrap">
                  <div class="thd-stat-bar" :style="{ width: systemInfo.memory.usedPercent + '%' }"></div>
                </div>
                <span class="thd-stat-value">{{ systemInfo.memory.usedPercent }}%</span>
              </div>
              <div class="thd-system-meta">
                <span>{{ systemInfo.os.hostname }}</span>
                <span>{{ systemInfo.memory.used }}/{{ systemInfo.memory.total }} GB RAM</span>
              </div>
            </div>
            <div v-else class="thd-card-error">Systemdaten nicht verfügbar</div>
          </div>
        </div>

        <!-- Sensors summary card -->
        <div class="col-12 col-md-4">
          <div class="thd-info-card">
            <div class="thd-info-card-header">
              <span class="thd-card-icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
              </span>
              <span class="thd-card-title">Sensoren</span>
            </div>
            <div v-if="sensorsLoading" class="thd-card-loading">
              <div class="thd-spinner-sm"></div>
            </div>
            <div v-else-if="latestReadings.length" class="thd-sensors-body">
              <div
                v-for="r in latestReadings"
                :key="r.sensorId"
                class="thd-sensor-row"
              >
                <span class="thd-sensor-name">{{ r.sensorName }}</span>
                <span class="thd-sensor-value">{{ r.value }} <small>{{ r.unit }}</small></span>
              </div>
            </div>
            <div v-else class="thd-card-error">Keine Sensordaten</div>
          </div>
        </div>
      </div>

      <!-- Mensa section -->
      <div class="thd-section-label">MENSA HEUTE</div>
      <div class="thd-mensa-card mb-4">
        <div v-if="mensaLoading" class="thd-card-loading py-3">
          <div class="thd-spinner-sm"></div>
        </div>
        <div v-else-if="mensa" class="thd-mensa-grid">
          <div
            v-for="meal in mensa.meals"
            :key="meal.name"
            class="thd-mensa-item"
          >
            <div class="thd-mensa-category">{{ meal.category }}</div>
            <div class="thd-mensa-name">{{ meal.name }}</div>
            <div class="thd-mensa-price">{{ meal.prices.students.toFixed(2) }} € <small>(Studierende)</small></div>
            <div class="thd-mensa-notes">
              <span v-for="note in meal.notes" :key="note" class="thd-mensa-tag">{{ note }}</span>
            </div>
          </div>
        </div>
        <div v-else class="thd-card-error py-3 px-4">Mensadaten nicht verfügbar</div>
        <div v-if="mensa?.mock" class="thd-mensa-mock-notice">Demo-Daten — Mensa API aktuell nicht erreichbar</div>
      </div>

    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useAuthStore } from '@/stores/stores_auth'
import { externalApi, type WeatherData, type MensaResponse } from '@/api/external'
import { sensorsApi, type SensorReading } from '@/api/sensors'

const auth = useAuthStore()

// ── State ─────────────────────────────────────────────
const weather = ref<WeatherData | null>(null)
const weatherLoading = ref(true)

const mensa = ref<MensaResponse | null>(null)
const mensaLoading = ref(true)

const systemInfo = ref<any>(null)
const systemLoading = ref(true)

const latestReadings = ref<SensorReading[]>([])
const sensorsLoading = ref(true)

// ── Data fetching ─────────────────────────────────────
async function fetchAll() {
  // Weather
  try {
    weather.value = await externalApi.getWeather()
  } catch {
    weather.value = null
  } finally {
    weatherLoading.value = false
  }

  // Mensa
  try {
    mensa.value = await externalApi.getMensa()
  } catch {
    mensa.value = null
  } finally {
    mensaLoading.value = false
  }

  // System info
  try {
    systemInfo.value = await sensorsApi.getSystemInfo()
  } catch {
    systemInfo.value = null
  } finally {
    systemLoading.value = false
  }

  // Latest sensor readings
  try {
    latestReadings.value = await sensorsApi.getLatest()
  } catch {
    latestReadings.value = []
  } finally {
    sensorsLoading.value = false
  }
}

onMounted(fetchAll)
</script>

<style scoped>
/* ── Page ─────────────────────────────────────────────── */
.thd-dashboard {
  background: var(--thd-page);
  min-height: 100vh;
}

/* ── Greeting bar ────────────────────────────────────── */
.thd-greeting-bar {
  background: var(--thd-white);
  border-bottom: 1px solid var(--thd-border);
  padding: 2.5rem 0 2rem;
}

.thd-greeting {
  font-size: clamp(1rem, 2.5vw, 1.5rem);
  font-weight: 300;
  letter-spacing: 0.18em;
  color: var(--thd-text);
  margin: 0;
  text-transform: uppercase;
}

/* ── Section label ───────────────────────────────────── */
.thd-section-label {
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--thd-muted);
  margin-bottom: 0.75rem;
}

/* ── Info cards (Weather, System, Sensors) ───────────── */
.thd-info-card {
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  height: 100%;
  min-height: 180px;
  display: flex;
  flex-direction: column;
}

.thd-info-card-header {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.85rem 1rem 0.6rem;
  border-bottom: 1px solid var(--thd-border-light);
}

.thd-card-icon {
  color: var(--thd-muted);
  display: flex;
  align-items: center;
}

.thd-card-title {
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--thd-muted);
  flex: 1;
}

.thd-mock-badge {
  font-size: 0.62rem;
  background: #f0f0f0;
  color: var(--thd-muted);
  padding: 0.1em 0.45em;
  border-radius: 2px;
  font-weight: 600;
  letter-spacing: 0.05em;
  text-transform: uppercase;
}

/* Live dot for system card */
.thd-live-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #3daa5c;
  animation: pulse 2s ease-in-out infinite;
}
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.4; }
}

/* ── Loading / error states ──────────────────────────── */
.thd-card-loading {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
}

.thd-card-error {
  flex: 1;
  display: flex;
  align-items: center;
  font-size: 0.8rem;
  color: var(--thd-muted);
  padding: 1rem;
}

.thd-spinner-sm {
  width: 20px;
  height: 20px;
  border: 2px solid var(--thd-border);
  border-top-color: var(--thd-cyan);
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* ── Weather body ────────────────────────────────────── */
.thd-weather-body {
  padding: 1rem;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}

.thd-weather-temp {
  font-size: 2.2rem;
  font-weight: 200;
  letter-spacing: -0.02em;
  color: var(--thd-text);
  line-height: 1;
}

.thd-weather-city {
  font-size: 0.85rem;
  font-weight: 600;
  color: var(--thd-text);
  margin-top: 0.25rem;
}

.thd-weather-desc {
  font-size: 0.8rem;
  color: var(--thd-muted);
  text-transform: capitalize;
}

.thd-weather-meta {
  display: flex;
  gap: 0.75rem;
  font-size: 0.75rem;
  color: var(--thd-muted);
  margin-top: auto;
  padding-top: 0.5rem;
  flex-wrap: wrap;
}

/* ── System body ─────────────────────────────────────── */
.thd-system-body {
  padding: 1rem;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 0.65rem;
}

.thd-stat-row {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.thd-stat-label {
  font-size: 0.72rem;
  font-weight: 600;
  color: var(--thd-muted);
  width: 32px;
  flex-shrink: 0;
  letter-spacing: 0.05em;
  text-transform: uppercase;
}

.thd-stat-bar-wrap {
  flex: 1;
  height: 5px;
  background: var(--thd-border);
  border-radius: 2px;
  overflow: hidden;
}

.thd-stat-bar {
  height: 100%;
  background: var(--thd-cyan);
  border-radius: 2px;
  transition: width 0.4s ease;
  max-width: 100%;
}

.thd-stat-value {
  font-size: 0.78rem;
  font-weight: 600;
  color: var(--thd-text);
  width: 38px;
  text-align: right;
  flex-shrink: 0;
}

.thd-system-meta {
  display: flex;
  justify-content: space-between;
  font-size: 0.72rem;
  color: var(--thd-muted);
  margin-top: auto;
  padding-top: 0.25rem;
}

/* ── Sensors body ────────────────────────────────────── */
.thd-sensors-body {
  padding: 0.75rem 1rem;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 0;
}

.thd-sensor-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.45rem 0;
  border-bottom: 1px solid var(--thd-border-light);
  font-size: 0.82rem;
}
.thd-sensor-row:last-child { border-bottom: none; }

.thd-sensor-name {
  color: var(--thd-muted);
  font-size: 0.78rem;
  flex: 1;
  padding-right: 0.5rem;
}

.thd-sensor-value {
  font-weight: 600;
  color: var(--thd-text);
  font-size: 0.88rem;
  white-space: nowrap;
}

.thd-sensor-value small {
  font-weight: 400;
  color: var(--thd-muted);
  font-size: 0.72rem;
}

/* ── Mensa card ──────────────────────────────────────── */
.thd-mensa-card {
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  overflow: hidden;
}

.thd-mensa-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  border-bottom: 1px solid var(--thd-border-light);
}

.thd-mensa-item {
  padding: 1rem 1.25rem;
  border-right: 1px solid var(--thd-border-light);
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
}
.thd-mensa-item:last-child { border-right: none; }

.thd-mensa-category {
  font-size: 0.65rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--thd-cyan);
}

.thd-mensa-name {
  font-size: 0.88rem;
  font-weight: 500;
  color: var(--thd-text);
  line-height: 1.3;
}

.thd-mensa-price {
  font-size: 0.78rem;
  color: var(--thd-muted);
  margin-top: 0.2rem;
}

.thd-mensa-price small {
  font-size: 0.68rem;
}

.thd-mensa-notes {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  margin-top: 0.25rem;
}

.thd-mensa-tag {
  font-size: 0.62rem;
  background: var(--thd-page);
  border: 1px solid var(--thd-border);
  color: var(--thd-muted);
  padding: 0.1em 0.4em;
  border-radius: 2px;
  text-transform: lowercase;
}

.thd-mensa-mock-notice {
  padding: 0.5rem 1.25rem;
  font-size: 0.72rem;
  color: var(--thd-muted);
  background: #fafafa;
}
</style>
