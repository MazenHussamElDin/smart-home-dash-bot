<template>
  <div class="thd-page">

    <!-- ── Page header ──────────────────────────────── -->
    <div class="thd-page-header">
      <div class="container-fluid px-4">
        <div class="thd-section-label">KONFIGURATION</div>
        <h1 class="thd-page-title mb-0">EINSTELLUNGEN</h1>
      </div>
    </div>

    <div class="container-fluid px-4 py-4">

      <!-- ── Save success / error banner ─────────────── -->
      <div v-if="saveSuccess" class="thd-banner thd-banner--success mb-3">
        ✓ Einstellungen erfolgreich gespeichert.
        <button class="thd-banner-close" @click="saveSuccess = false">✕</button>
      </div>
      <div v-if="saveError" class="thd-banner thd-banner--error mb-3">
        ✕ {{ saveError }}
        <button class="thd-banner-close" @click="saveError = ''">✕</button>
      </div>

      <div class="row g-4">

        <!-- ── LEFT: Sensor configs ──────────────────── -->
        <div class="col-12 col-lg-8">
          <div class="thd-section-label">SENSOREN</div>
          <div class="thd-settings-card">

            <!-- Loading state -->
            <div v-if="loading" class="thd-card-loading">
              <div class="thd-spinner-md"></div>
            </div>

            <template v-else>
              <!-- Sensor rows -->
              <div
                v-for="(sensor, idx) in sensors"
                :key="sensor.id"
                class="thd-sensor-row"
                :class="{ 'thd-sensor-row--inactive': !sensor.active }"
              >
                <!-- Row header -->
                <div class="thd-sensor-row-header">
                  <div class="d-flex align-items-center gap-2">
                    <span class="thd-sensor-index">{{ idx + 1 }}</span>
                    <span class="thd-sensor-id">{{ sensor.id }}</span>
                    <span class="thd-sensor-type-badge">{{ sensor.type }}</span>
                  </div>
                  <!-- Active toggle -->
                  <label class="thd-toggle">
                    <input type="checkbox" v-model="sensor.active" />
                    <span class="thd-toggle-track"></span>
                    <span class="thd-toggle-label">{{ sensor.active ? 'Aktiv' : 'Inaktiv' }}</span>
                  </label>
                </div>

                <!-- Fields grid -->
                <div class="thd-sensor-fields">
                  <!-- Name -->
                  <div class="thd-field-group">
                    <label class="thd-field-label">NAME</label>
                    <input
                      v-model.trim="sensor.name"
                      type="text"
                      class="thd-input"
                      :class="{ 'thd-input--error': sensorErrors[idx]?.name }"
                      placeholder="Sensorname"
                    />
                    <span v-if="sensorErrors[idx]?.name" class="thd-field-error">{{ sensorErrors[idx].name }}</span>
                  </div>

                  <!-- IP -->
                  <div class="thd-field-group">
                    <label class="thd-field-label">IP-ADRESSE</label>
                    <input
                      v-model.trim="sensor.ip"
                      type="text"
                      class="thd-input"
                      :class="{ 'thd-input--error': sensorErrors[idx]?.ip }"
                      placeholder="192.168.1.100"
                    />
                    <span v-if="sensorErrors[idx]?.ip" class="thd-field-error">{{ sensorErrors[idx].ip }}</span>
                  </div>

                  <!-- Port -->
                  <div class="thd-field-group">
                    <label class="thd-field-label">PORT</label>
                    <input
                      v-model.number="sensor.port"
                      type="number"
                      class="thd-input"
                      :class="{ 'thd-input--error': sensorErrors[idx]?.port }"
                      placeholder="8080"
                      min="1"
                      max="65535"
                    />
                    <span v-if="sensorErrors[idx]?.port" class="thd-field-error">{{ sensorErrors[idx].port }}</span>
                  </div>

                  <!-- Polling interval -->
                  <div class="thd-field-group">
                    <label class="thd-field-label">INTERVALL (ms)</label>
                    <input
                      v-model.number="sensor.pollingInterval"
                      type="number"
                      class="thd-input"
                      :class="{ 'thd-input--error': sensorErrors[idx]?.pollingInterval }"
                      placeholder="5000"
                      min="500"
                      step="500"
                    />
                    <span v-if="sensorErrors[idx]?.pollingInterval" class="thd-field-error">{{ sensorErrors[idx].pollingInterval }}</span>
                  </div>

                  <!-- Unit -->
                  <div class="thd-field-group">
                    <label class="thd-field-label">EINHEIT</label>
                    <input
                      v-model.trim="sensor.unit"
                      type="text"
                      class="thd-input"
                      placeholder="°C"
                    />
                  </div>

                  <!-- Reachability test -->
                  <div class="thd-field-group thd-field-group--reach">
                    <label class="thd-field-label">ERREICHBARKEIT</label>
                    <div class="thd-reach-row">
                      <button
                        class="thd-reach-btn"
                        @click="testReachability(idx)"
                        :disabled="reachability[idx]?.loading"
                      >
                        <span v-if="reachability[idx]?.loading" class="thd-spinner-sm-inline"></span>
                        {{ reachability[idx]?.loading ? 'Teste…' : 'Testen' }}
                      </button>
                      <span v-if="reachability[idx]" class="thd-reach-result" :class="reachability[idx].reachable ? 'ok' : 'fail'">
                        <template v-if="reachability[idx].reachable">
                          ✓ Erreichbar ({{ reachability[idx].latencyMs }}ms)
                        </template>
                        <template v-else>
                          ✕ {{ reachability[idx].error ?? 'Nicht erreichbar' }}
                        </template>
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Empty -->
              <div v-if="!sensors.length" class="thd-empty-state">
                Keine Sensoren konfiguriert.
              </div>
            </template>
          </div>
        </div>

        <!-- ── RIGHT: General settings ───────────────── -->
        <div class="col-12 col-lg-4">
          <div class="thd-section-label">ALLGEMEIN</div>
          <div class="thd-settings-card">
            <div v-if="loading" class="thd-card-loading">
              <div class="thd-spinner-md"></div>
            </div>
            <div v-else class="thd-general-fields">

              <div class="thd-field-group">
                <label class="thd-field-label">DASHBOARD-TITEL</label>
                <input
                  v-model.trim="general.dashboardTitle"
                  type="text"
                  class="thd-input"
                  :class="{ 'thd-input--error': generalErrors.dashboardTitle }"
                  placeholder="Smart Home Dashboard"
                />
                <span v-if="generalErrors.dashboardTitle" class="thd-field-error">{{ generalErrors.dashboardTitle }}</span>
              </div>

              <div class="thd-field-group">
                <label class="thd-field-label">AKTUALISIERUNGSRATE (ms)</label>
                <input
                  v-model.number="general.refreshRate"
                  type="number"
                  class="thd-input"
                  :class="{ 'thd-input--error': generalErrors.refreshRate }"
                  min="1000"
                  step="1000"
                  placeholder="5000"
                />
                <span v-if="generalErrors.refreshRate" class="thd-field-error">{{ generalErrors.refreshRate }}</span>
              </div>

              <div class="thd-field-group">
                <label class="thd-field-label">MENSA-ID</label>
                <input
                  v-model.trim="general.mensaId"
                  type="text"
                  class="thd-input"
                  :class="{ 'thd-input--error': generalErrors.mensaId }"
                  placeholder="187"
                />
                <span v-if="generalErrors.mensaId" class="thd-field-error">{{ generalErrors.mensaId }}</span>
              </div>

              <div class="thd-field-group">
                <label class="thd-field-label">STADT (WETTER)</label>
                <input
                  v-model.trim="general.weatherCity"
                  type="text"
                  class="thd-input"
                  placeholder="Deggendorf"
                />
              </div>

              <div class="thd-field-group">
                <label class="thd-field-label">BREITENGRAD</label>
                <input
                  v-model.trim="general.weatherLat"
                  type="text"
                  class="thd-input"
                  :class="{ 'thd-input--error': generalErrors.weatherLat }"
                  placeholder="48.8317"
                />
                <span v-if="generalErrors.weatherLat" class="thd-field-error">{{ generalErrors.weatherLat }}</span>
              </div>

              <div class="thd-field-group">
                <label class="thd-field-label">LÄNGENGRAD</label>
                <input
                  v-model.trim="general.weatherLon"
                  type="text"
                  class="thd-input"
                  :class="{ 'thd-input--error': generalErrors.weatherLon }"
                  placeholder="12.9583"
                />
                <span v-if="generalErrors.weatherLon" class="thd-field-error">{{ generalErrors.weatherLon }}</span>
              </div>

            </div>
          </div>
        </div>
      </div>

      <!-- ── Save button ───────────────────────────────── -->
      <div class="thd-save-row mt-4">
        <span class="thd-save-hint">Änderungen werden sofort in settings.json gespeichert.</span>
        <button class="btn-thd" @click="saveAll" :disabled="saving">
          <span v-if="saving" class="thd-spinner-sm-inline"></span>
          {{ saving ? 'Speichert…' : 'Speichern' }}
        </button>
      </div>

    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { settingsApi, type SensorConfig, type GeneralSettings } from '@/api/settings'

// ── State ──────────────────────────────────────────────
const loading = ref(true)
const saving = ref(false)
const saveSuccess = ref(false)
const saveError = ref('')

const sensors = ref<SensorConfig[]>([])
const general = reactive<GeneralSettings>({
  dashboardTitle: '',
  refreshRate: 5000,
  theme: 'light',
  mensaId: '',
  weatherLat: '',
  weatherLon: '',
  weatherCity: '',
})

// Per-sensor validation errors
const sensorErrors = ref<Record<number, Record<string, string>>>({})
// General validation errors
const generalErrors = reactive<Record<string, string>>({})

// Per-sensor reachability result
interface ReachResult {
  loading: boolean
  reachable: boolean
  latencyMs: number
  error?: string
}
const reachability = ref<Record<number, ReachResult>>({})

// ── Load settings ──────────────────────────────────────
async function loadSettings() {
  loading.value = true
  try {
    const data = await settingsApi.getAll()
    sensors.value = data.sensors.map(s => ({ ...s }))
    Object.assign(general, data.general)
  } catch {
    saveError.value = 'Einstellungen konnten nicht geladen werden.'
  } finally {
    loading.value = false
  }
}

// ── Validation ─────────────────────────────────────────
function validateSensors(): boolean {
  sensorErrors.value = {}
  let valid = true

  sensors.value.forEach((s, idx) => {
    const errs: Record<string, string> = {}

    if (!s.name.trim()) {
      errs.name = 'Name ist erforderlich'
      valid = false
    }

    if (!s.ip.trim()) {
      errs.ip = 'IP-Adresse ist erforderlich'
      valid = false
    } else if (!/^[\w.\-]+$/.test(s.ip.trim())) {
      errs.ip = 'Ungültige IP-Adresse oder Hostname'
      valid = false
    }

    const port = Number(s.port)
    if (isNaN(port) || port < 1 || port > 65535) {
      errs.port = 'Port muss zwischen 1 und 65535 liegen'
      valid = false
    }

    const interval = Number(s.pollingInterval)
    if (isNaN(interval) || interval < 500) {
      errs.pollingInterval = 'Mindestens 500ms'
      valid = false
    }

    if (Object.keys(errs).length) sensorErrors.value[idx] = errs
  })

  return valid
}

function validateGeneral(): boolean {
  Object.keys(generalErrors).forEach(k => delete generalErrors[k])
  let valid = true

  if (!general.dashboardTitle.trim()) {
    generalErrors.dashboardTitle = 'Titel ist erforderlich'
    valid = false
  }

  const rate = Number(general.refreshRate)
  if (isNaN(rate) || rate < 1000) {
    generalErrors.refreshRate = 'Mindestens 1000ms'
    valid = false
  }

  if (!general.mensaId.trim()) {
    generalErrors.mensaId = 'Mensa-ID ist erforderlich'
    valid = false
  }

  const latNum = parseFloat(general.weatherLat)
  if (isNaN(latNum) || latNum < -90 || latNum > 90) {
    generalErrors.weatherLat = 'Breitengrad: -90 bis 90'
    valid = false
  }

  const lonNum = parseFloat(general.weatherLon)
  if (isNaN(lonNum) || lonNum < -180 || lonNum > 180) {
    generalErrors.weatherLon = 'Längengrad: -180 bis 180'
    valid = false
  }

  return valid
}

// ── Save ───────────────────────────────────────────────
async function saveAll() {
  saveSuccess.value = false
  saveError.value = ''

  const sensorsOk = validateSensors()
  const generalOk = validateGeneral()
  if (!sensorsOk || !generalOk) return

  saving.value = true
  try {
    await settingsApi.updateAll({
      sensors: sensors.value,
      general: { ...general },
    })
    saveSuccess.value = true
    window.scrollTo({ top: 0, behavior: 'smooth' })
  } catch (err: unknown) {
    saveError.value = err instanceof Error ? err.message : 'Speichern fehlgeschlagen'
  } finally {
    saving.value = false
  }
}

// ── Reachability test ──────────────────────────────────
async function testReachability(idx: number) {
  const sensor = sensors.value[idx]
  reachability.value[idx] = { loading: true, reachable: false, latencyMs: 0 }

  try {
    const result = await settingsApi.testReachability(sensor.ip, sensor.port)
    reachability.value[idx] = {
      loading: false,
      reachable: result.reachable,
      latencyMs: result.latencyMs,
      error: result.error,
    }
  } catch {
    reachability.value[idx] = {
      loading: false,
      reachable: false,
      latencyMs: 0,
      error: 'Anfrage fehlgeschlagen',
    }
  }
}

onMounted(loadSettings)
</script>

<style scoped>
/* ── Page ─────────────────────────────────────────────── */
.thd-page {
  background: var(--thd-page);
  min-height: 100vh;
}
.thd-page-header {
  background: var(--thd-white);
  border-bottom: 1px solid var(--thd-border);
  padding: 1.75rem 0 1.5rem;
}
.thd-page-title {
  font-size: clamp(1rem, 2.5vw, 1.4rem);
  font-weight: 300;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  color: var(--thd-text);
}
.thd-section-label {
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--thd-muted);
  margin-bottom: 0.75rem;
}

/* ── Banners ─────────────────────────────────────────── */
.thd-banner {
  padding: 0.7rem 1rem;
  border-radius: 3px;
  font-size: 0.85rem;
  font-weight: 500;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.thd-banner--success {
  background: #ecfdf5;
  border: 1px solid #6ee7b7;
  color: #065f46;
}
.thd-banner--error {
  background: #fef2f2;
  border: 1px solid #fca5a5;
  color: #b91c1c;
}
.thd-banner-close {
  background: none;
  border: none;
  cursor: pointer;
  color: inherit;
  font-size: 0.8rem;
  padding: 0;
  opacity: 0.7;
}
.thd-banner-close:hover { opacity: 1; }

/* ── Settings card ───────────────────────────────────── */
.thd-settings-card {
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  overflow: hidden;
}

/* ── Sensor rows ─────────────────────────────────────── */
.thd-sensor-row {
  border-bottom: 1px solid var(--thd-border);
  padding: 1.1rem 1.25rem;
  transition: background 0.15s;
}
.thd-sensor-row:last-child { border-bottom: none; }
.thd-sensor-row--inactive { background: #fafafa; opacity: 0.75; }

.thd-sensor-row-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 0.9rem;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.thd-sensor-index {
  width: 22px;
  height: 22px;
  background: var(--thd-page);
  border: 1px solid var(--thd-border);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.7rem;
  font-weight: 700;
  color: var(--thd-muted);
  flex-shrink: 0;
}

.thd-sensor-id {
  font-size: 0.78rem;
  font-weight: 600;
  color: var(--thd-text);
  font-family: monospace;
}

.thd-sensor-type-badge {
  font-size: 0.62rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--thd-cyan);
  background: rgba(41,171,226,0.08);
  padding: 0.15em 0.5em;
  border-radius: 2px;
}

/* ── Active toggle ───────────────────────────────────── */
.thd-toggle {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  user-select: none;
}
.thd-toggle input { display: none; }
.thd-toggle-track {
  width: 34px;
  height: 18px;
  background: var(--thd-border);
  border-radius: 9px;
  position: relative;
  transition: background 0.2s;
}
.thd-toggle-track::after {
  content: '';
  position: absolute;
  left: 2px;
  top: 2px;
  width: 14px;
  height: 14px;
  background: #fff;
  border-radius: 50%;
  transition: transform 0.2s;
  box-shadow: 0 1px 3px rgba(0,0,0,0.2);
}
.thd-toggle input:checked ~ .thd-toggle-track {
  background: var(--thd-cyan);
}
.thd-toggle input:checked ~ .thd-toggle-track::after {
  transform: translateX(16px);
}
.thd-toggle-label {
  font-size: 0.72rem;
  font-weight: 600;
  color: var(--thd-muted);
  letter-spacing: 0.05em;
  text-transform: uppercase;
}

/* ── Sensor fields grid ──────────────────────────────── */
.thd-sensor-fields {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 0.75rem;
}
.thd-field-group--reach {
  grid-column: span 2;
}
@media (max-width: 575px) {
  .thd-field-group--reach { grid-column: span 1; }
}

/* ── General fields ──────────────────────────────────── */
.thd-general-fields {
  padding: 1.1rem 1.25rem;
  display: flex;
  flex-direction: column;
  gap: 0.85rem;
}

/* ── Shared field styles ─────────────────────────────── */
.thd-field-group {
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
}
.thd-field-label {
  font-size: 0.62rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--thd-muted);
}
.thd-input {
  width: 100%;
  padding: 0.45rem 0.65rem;
  font-size: 0.85rem;
  border: 1px solid var(--thd-border);
  border-radius: 3px;
  background: var(--thd-white);
  color: var(--thd-text);
  outline: none;
  transition: border-color 0.15s, box-shadow 0.15s;
}
.thd-input:focus {
  border-color: var(--thd-cyan);
  box-shadow: 0 0 0 3px rgba(41,171,226,0.1);
}
.thd-input--error { border-color: var(--thd-danger); }
.thd-field-error {
  font-size: 0.72rem;
  color: var(--thd-danger);
}

/* ── Reachability ────────────────────────────────────── */
.thd-reach-row {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  flex-wrap: wrap;
}
.thd-reach-btn {
  background: var(--thd-page);
  border: 1px solid var(--thd-border);
  color: var(--thd-text);
  font-size: 0.78rem;
  font-weight: 600;
  padding: 0.38rem 0.85rem;
  border-radius: 3px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.4rem;
  transition: border-color 0.15s, background 0.15s;
  letter-spacing: 0.03em;
}
.thd-reach-btn:hover:not(:disabled) {
  border-color: var(--thd-cyan);
  color: var(--thd-cyan);
}
.thd-reach-btn:disabled { opacity: 0.65; cursor: not-allowed; }

.thd-reach-result {
  font-size: 0.78rem;
  font-weight: 600;
}
.thd-reach-result.ok   { color: #3daa5c; }
.thd-reach-result.fail { color: var(--thd-danger); }

/* ── Save row ────────────────────────────────────────── */
.thd-save-row {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 1rem;
  flex-wrap: wrap;
  padding-bottom: 2rem;
}
.thd-save-hint {
  font-size: 0.78rem;
  color: var(--thd-muted);
}

/* ── Buttons ─────────────────────────────────────────── */
.btn-thd {
  background: var(--thd-cyan);
  border: none;
  color: #fff;
  font-size: 0.85rem;
  font-weight: 600;
  padding: 0.55rem 1.5rem;
  border-radius: 3px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.4rem;
  transition: background 0.15s;
  letter-spacing: 0.03em;
}
.btn-thd:hover:not(:disabled) { background: var(--thd-cyan-dark); }
.btn-thd:disabled { opacity: 0.65; cursor: not-allowed; }

/* ── Helpers ─────────────────────────────────────────── */
.thd-card-loading {
  padding: 3rem;
  display: flex;
  align-items: center;
  justify-content: center;
}
.thd-empty-state {
  padding: 2rem;
  text-align: center;
  font-size: 0.85rem;
  color: var(--thd-muted);
}
.thd-spinner-md {
  width: 28px;
  height: 28px;
  border: 3px solid var(--thd-border);
  border-top-color: var(--thd-cyan);
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
.thd-spinner-sm-inline {
  display: inline-block;
  width: 12px;
  height: 12px;
  border: 2px solid rgba(255,255,255,0.4);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
</style>
