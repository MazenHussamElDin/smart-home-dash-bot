import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { authApi, type AuthUser } from '@/api/api_auth'

export const useAuthStore = defineStore('auth', () => {
  // ── State ───────────────────────────────────────────
  const token = ref<string | null>(localStorage.getItem('token'))
  const user = ref<AuthUser | null>(null)
  const loading = ref(false)
  const error = ref<string | null>(null)

  // ── Getters ─────────────────────────────────────────
  const isAuthenticated = computed(() => !!token.value)
  const username = computed(() => user.value?.username ?? '')
  const role = computed(() => user.value?.role ?? '')

  // ── Actions ─────────────────────────────────────────
  async function login(email: string, password: string): Promise<void> {
    loading.value = true
    error.value = null
    try {
      const res = await authApi.login(email, password)
      token.value = res.token
      user.value = res.user
      localStorage.setItem('token', res.token)
    } catch (err: unknown) {
      error.value = err instanceof Error ? err.message : 'Login failed'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function register(username: string, email: string, password: string): Promise<void> {
    loading.value = true
    error.value = null
    try {
      const res = await authApi.register(username, email, password)
      token.value = res.token
      user.value = res.user
      localStorage.setItem('token', res.token)
    } catch (err: unknown) {
      error.value = err instanceof Error ? err.message : 'Registration failed'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function fetchCurrentUser(): Promise<void> {
    if (!token.value) return
    try {
      user.value = await authApi.me()
    } catch {
      // Token is invalid or expired — log out silently
      logout()
    }
  }

  function logout(): void {
    token.value = null
    user.value = null
    localStorage.removeItem('token')
  }

  function clearError(): void {
    error.value = null
  }

  return {
    token,
    user,
    loading,
    error,
    isAuthenticated,
    username,
    role,
    login,
    register,
    fetchCurrentUser,
    logout,
    clearError,
  }
})
