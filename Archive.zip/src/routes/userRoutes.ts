import { Router, Request, Response } from 'express';
import User from '../models/User';
import { logger } from '../utils/logger';

const router = Router();

/**
 * GET /api/users
 * List all users
 */
router.get('/', async (_req: Request, res: Response) => {
  try {
    const users = await User.find().sort({ createdAt: -1 });
    res.json(users);
  } catch (error) {
    logger.error({ error }, 'Error fetching users');
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

/**
 * GET /api/users/:id
 * Get a specific user
 */
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    logger.error({ error }, 'Error fetching user');
    res.status(500).json({ error: 'Failed to fetch user' });
  }
});

/**
 * POST /api/users
 * Create a new user (form submission from frontend)
 * Validates: required fields, email format, trimmed strings
 */
router.post('/', async (req: Request, res: Response) => {
  try {
    const { firstName, lastName, email } = req.body;

    // Required field check
    if (!firstName?.trim() || !lastName?.trim() || !email?.trim()) {
      return res.status(400).json({
        error: 'Missing required fields: firstName, lastName, email',
      });
    }

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      return res.status(400).json({ error: 'Invalid email format' });
    }

    const user = new User({
      ...req.body,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      email: email.trim().toLowerCase(),
    });

    const saved = await user.save();
    logger.info(`User created: ${saved.firstName} ${saved.lastName}`);
    res.status(201).json(saved);
  } catch (error) {
    logger.error({ error }, 'Error creating user');
    res.status(400).json({ error: 'Failed to create user' });
  }
});

/**
 * PUT /api/users/:id
 * Update a user
 */
router.put('/:id', async (req: Request, res: Response) => {
  try {
    const updated = await User.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!updated) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(updated);
  } catch (error) {
    logger.error({ error }, 'Error updating user');
    res.status(400).json({ error: 'Failed to update user' });
  }
});

/**
 * DELETE /api/users/:id
 * Delete a user
 */
router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const result = await User.findByIdAndDelete(req.params.id);
    if (!result) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.status(204).send();
  } catch (error) {
    logger.error({ error }, 'Error deleting user');
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

export default router;
