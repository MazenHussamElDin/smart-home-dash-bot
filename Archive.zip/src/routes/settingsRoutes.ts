import { Router, Request, Response } from 'express';
import { settingsManager } from '../config/settingsManager';
import { logger } from '../utils/logger';

const router = Router();

/**
 * GET /api/settings
 * Returns the full settings object
 */
router.get('/', (_req: Request, res: Response) => {
  try {
    res.json(settingsManager.getAll());
  } catch (error) {
    logger.error({ error }, 'Error reading settings');
    res.status(500).json({ error: 'Failed to read settings' });
  }
});

/**
 * GET /api/settings/sensors
 * Returns only the active sensor configurations
 */
router.get('/sensors', (_req: Request, res: Response) => {
  try {
    res.json(settingsManager.getActiveSensors());
  } catch (error) {
    logger.error({ error }, 'Error reading sensor settings');
    res.status(500).json({ error: 'Failed to read sensor settings' });
  }
});

/**
 * POST /api/settings/sensors/test
 * Reachability test for a sensor endpoint.
 * Body: { ip: string, port: number, path?: string }
 * Returns: { reachable: boolean, latencyMs?: number, error?: string }
 *
 * Required by course: "Es sollte ein Erreichbarkeits-Test durchgeführt werden"
 */
router.post('/sensors/test', async (req: Request, res: Response) => {
  const { ip, port, path: urlPath } = req.body;

  if (!ip || !port) {
    return res.status(400).json({ error: 'Missing required fields: ip, port' });
  }

  // Validate port is a number
  const portNum = Number(port);
  if (isNaN(portNum) || portNum < 1 || portNum > 65535) {
    return res.status(400).json({ error: 'Invalid port number' });
  }

  const cleanPath = urlPath ? String(urlPath).replace(/^\/+/, '') : '';
  const url = `http://${ip}:${portNum}${cleanPath ? '/' + cleanPath : ''}`;

  const start = Date.now();
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3000); // 3s timeout

    const response = await fetch(url, {
      method: 'GET',
      signal: controller.signal,
    });

    clearTimeout(timeout);
    const latencyMs = Date.now() - start;

    logger.info(`Reachability test for ${url}: ${response.status} in ${latencyMs}ms`);
    res.json({ reachable: true, latencyMs, status: response.status });
  } catch (error: any) {
    const latencyMs = Date.now() - start;
    const isTimeout = error?.name === 'AbortError';
    logger.info(`Reachability test for ${url}: unreachable (${isTimeout ? 'timeout' : error?.message})`);
    res.json({
      reachable: false,
      latencyMs,
      error: isTimeout ? 'Connection timed out after 3s' : 'Host unreachable',
    });
  }
});

/**
 * PUT /api/settings
 * Replace the entire settings object
 */
router.put('/', (req: Request, res: Response) => {
  try {
    if (!req.body.sensors || !req.body.general) {
      return res.status(400).json({
        error: 'Settings must contain both "sensors" and "general" sections',
      });
    }

    const updated = settingsManager.update(req.body);
    logger.info('Full settings updated');
    res.json({ message: 'Settings updated successfully', settings: updated });
  } catch (error) {
    logger.error({ error }, 'Error updating settings');
    res.status(500).json({ error: 'Failed to update settings' });
  }
});

/**
 * PUT /api/settings/general
 * Update only general settings
 */
router.put('/general', (req: Request, res: Response) => {
  try {
    const updated = settingsManager.updateGeneral(req.body);
    res.json({ message: 'General settings updated', settings: updated });
  } catch (error) {
    logger.error({ error }, 'Error updating general settings');
    res.status(500).json({ error: 'Failed to update general settings' });
  }
});

/**
 * PUT /api/settings/sensors
 * Update only sensor list
 */
router.put('/sensors', (req: Request, res: Response) => {
  try {
    if (!Array.isArray(req.body)) {
      return res.status(400).json({ error: 'Body must be an array of sensor configs' });
    }

    const updated = settingsManager.updateSensors(req.body);
    res.json({ message: 'Sensor settings updated', settings: updated });
  } catch (error) {
    logger.error({ error }, 'Error updating sensor settings');
    res.status(500).json({ error: 'Failed to update sensor settings' });
  }
});

export default router;
