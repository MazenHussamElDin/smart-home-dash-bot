import { Router, Request, Response } from 'express';
import si from 'systeminformation';
import { logger } from '../utils/logger';

const router = Router();

/**
 * GET /api/system/info
 * Returns a summary of the host machine's current state
 * This is REAL data from the machine running the backend
 */
router.get('/info', async (_req: Request, res: Response) => {
  try {
    const [cpu, mem, osInfo, time] = await Promise.all([
      si.currentLoad(),
      si.mem(),
      si.osInfo(),
      si.time(),
    ]);

    res.json({
      os: {
        platform: osInfo.platform,
        distro: osInfo.distro,
        hostname: osInfo.hostname,
      },
      cpu: {
        currentLoad: Math.round(cpu.currentLoad * 10) / 10,
        cores: cpu.cpus.length,
      },
      memory: {
        total: Math.round(mem.total / 1024 / 1024 / 1024 * 10) / 10,  // GB
        used: Math.round(mem.used / 1024 / 1024 / 1024 * 10) / 10,
        free: Math.round(mem.free / 1024 / 1024 / 1024 * 10) / 10,
        usedPercent: Math.round((mem.used / mem.total) * 100 * 10) / 10,
      },
      uptime: time.uptime,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error(`Error fetching system info: ${error}`);
    res.status(500).json({ error: 'Failed to fetch system info' });
  }
});

/**
 * GET /api/system/cpu
 * Returns current CPU temperature and load
 * This is the "real sensor" data updated every second for dynamic charts
 */
router.get('/cpu', async (_req: Request, res: Response) => {
  try {
    const [cpuTemp, cpuLoad] = await Promise.all([
      si.cpuTemperature(),
      si.currentLoad(),
    ]);

    res.json({
      sensorId: 'system-cpu-temp',
      sensorName: 'CPU Temperature',
      type: 'temperature',
      value: cpuTemp.main !== null ? cpuTemp.main : -1,  // -1 if not available
      unit: '°C',
      cpuLoad: Math.round(cpuLoad.currentLoad * 10) / 10,
      loadUnit: '%',
      timestamp: new Date().toISOString(),
      real: true,  // flag: this is real data, not simulated
    });
  } catch (error) {
    logger.error(`Error fetching CPU data: ${error}`);
    res.status(500).json({ error: 'Failed to fetch CPU data' });
  }
});

/**
 * GET /api/system/memory
 * Returns current memory usage — real sensor data
 */
router.get('/memory', async (_req: Request, res: Response) => {
  try {
    const mem = await si.mem();

    res.json({
      sensorId: 'system-memory',
      sensorName: 'Memory Usage',
      type: 'memory',
      value: Math.round((mem.used / mem.total) * 100 * 10) / 10,
      unit: '%',
      totalGB: Math.round(mem.total / 1024 / 1024 / 1024 * 10) / 10,
      usedGB: Math.round(mem.used / 1024 / 1024 / 1024 * 10) / 10,
      timestamp: new Date().toISOString(),
      real: true,
    });
  } catch (error) {
    logger.error(`Error fetching memory data: ${error}`);
    res.status(500).json({ error: 'Failed to fetch memory data' });
  }
});

/**
 * GET /api/system/disk
 * Returns disk usage — real sensor data
 */
router.get('/disk', async (_req: Request, res: Response) => {
  try {
    const disks = await si.fsSize();
    const mainDisk = disks[0]; // primary disk

    res.json({
      sensorId: 'system-disk',
      sensorName: 'Disk Usage',
      type: 'storage',
      value: mainDisk ? Math.round(mainDisk.use * 10) / 10 : 0,
      unit: '%',
      totalGB: mainDisk ? Math.round(mainDisk.size / 1024 / 1024 / 1024 * 10) / 10 : 0,
      usedGB: mainDisk ? Math.round(mainDisk.used / 1024 / 1024 / 1024 * 10) / 10 : 0,
      timestamp: new Date().toISOString(),
      real: true,
    });
  } catch (error) {
    logger.error(`Error fetching disk data: ${error}`);
    res.status(500).json({ error: 'Failed to fetch disk data' });
  }
});

/**
 * GET /api/system/network
 * Returns network stats — real sensor data
 */
router.get('/network', async (_req: Request, res: Response) => {
  try {
    const net = await si.networkStats();
    const primary = net[0];

    res.json({
      sensorId: 'system-network',
      sensorName: 'Network Activity',
      type: 'network',
      rxSec: primary ? Math.round(primary.rx_sec / 1024) : 0,  // KB/s
      txSec: primary ? Math.round(primary.tx_sec / 1024) : 0,
      unit: 'KB/s',
      interface: primary ? primary.iface : 'unknown',
      timestamp: new Date().toISOString(),
      real: true,
    });
  } catch (error) {
    logger.error(`Error fetching network data: ${error}`);
    res.status(500).json({ error: 'Failed to fetch network data' });
  }
});

/**
 * GET /api/system/all
 * Returns all system readings at once — for the dynamic chart
 * Frontend polls this every 1-2 seconds
 */
router.get('/all', async (_req: Request, res: Response) => {
  try {
    const [cpuTemp, cpuLoad, mem, disks, net] = await Promise.all([
      si.cpuTemperature(),
      si.currentLoad(),
      si.mem(),
      si.fsSize(),
      si.networkStats(),
    ]);

    const mainDisk = disks[0];
    const primaryNet = net[0];

    res.json({
      timestamp: new Date().toISOString(),
      real: true,
      readings: [
        {
          sensorId: 'system-cpu-temp',
          sensorName: 'CPU Temperature',
          type: 'temperature',
          value: cpuTemp.main !== null ? cpuTemp.main : -1,
          unit: '°C',
        },
        {
          sensorId: 'system-cpu-load',
          sensorName: 'CPU Load',
          type: 'load',
          value: Math.round(cpuLoad.currentLoad * 10) / 10,
          unit: '%',
        },
        {
          sensorId: 'system-memory',
          sensorName: 'Memory Usage',
          type: 'memory',
          value: Math.round((mem.used / mem.total) * 100 * 10) / 10,
          unit: '%',
        },
        {
          sensorId: 'system-disk',
          sensorName: 'Disk Usage',
          type: 'storage',
          value: mainDisk ? Math.round(mainDisk.use * 10) / 10 : 0,
          unit: '%',
        },
        {
          sensorId: 'system-net-rx',
          sensorName: 'Network Download',
          type: 'network',
          value: primaryNet ? Math.round(primaryNet.rx_sec / 1024) : 0,
          unit: 'KB/s',
        },
      ],
    });
  } catch (error) {
    logger.error(`Error fetching all system data: ${error}`);
    res.status(500).json({ error: 'Failed to fetch system data' });
  }
});

export default router;
