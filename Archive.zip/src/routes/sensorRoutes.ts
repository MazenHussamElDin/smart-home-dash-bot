import { Router, Request, Response } from 'express';
import SensorReading from '../models/SensorReading';
import { logger } from '../utils/logger';

const router = Router();

/**
 * GET /api/sensors
 * Query params: sensorId, type, limit, from, to
 */
router.get('/', async (req: Request, res: Response) => {
  try {
    const { sensorId, type, limit, from, to } = req.query;
    const filter: Record<string, any> = {};

    if (sensorId) filter.sensorId = sensorId;
    if (type) filter.type = type;

    if (from || to) {
      filter.timestamp = {};
      if (from) filter.timestamp.$gte = new Date(from as string);
      if (to) filter.timestamp.$lte = new Date(to as string);
    }

    const readings = await SensorReading.find(filter)
      .sort({ timestamp: -1 })
      .limit(Number(limit) || 100);

    res.json(readings);
  } catch (error) {
    logger.error({ error }, 'Error fetching sensor readings');
    res.status(500).json({ error: 'Failed to fetch sensor readings' });
  }
});

/**
 * GET /api/sensors/latest
 * Returns the most recent reading for each unique sensorId
 */
router.get('/latest', async (_req: Request, res: Response) => {
  try {
    const latest = await SensorReading.aggregate([
      { $sort: { timestamp: -1 } },
      {
        $group: {
          _id: '$sensorId',
          sensorName: { $first: '$sensorName' },
          type: { $first: '$type' },
          value: { $first: '$value' },
          unit: { $first: '$unit' },
          timestamp: { $first: '$timestamp' },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    res.json(
      latest.map((r) => ({
        sensorId: r._id,
        sensorName: r.sensorName,
        type: r.type,
        value: r.value,
        unit: r.unit,
        timestamp: r.timestamp,
      }))
    );
  } catch (error) {
    logger.error({ error }, 'Error fetching latest readings');
    res.status(500).json({ error: 'Failed to fetch latest readings' });
  }
});

/**
 * GET /api/sensors/stats
 * Returns min, max, avg for each sensor
 * Query params: sensorId, hours (default 24)
 */
router.get('/stats', async (req: Request, res: Response) => {
  try {
    const hours = Number(req.query.hours) || 24;
    const since = new Date(Date.now() - hours * 60 * 60 * 1000);
    const matchFilter: Record<string, any> = { timestamp: { $gte: since } };

    if (req.query.sensorId) {
      matchFilter.sensorId = req.query.sensorId;
    }

    const stats = await SensorReading.aggregate([
      { $match: matchFilter },
      {
        $group: {
          _id: { sensorId: '$sensorId', type: '$type' },
          sensorName: { $first: '$sensorName' },
          unit: { $first: '$unit' },
          min: { $min: '$value' },
          max: { $max: '$value' },
          avg: { $avg: '$value' },
          count: { $sum: 1 },
        },
      },
    ]);

    res.json(
      stats.map((s) => ({
        sensorId: s._id.sensorId,
        type: s._id.type,
        sensorName: s.sensorName,
        unit: s.unit,
        min: Math.round(s.min * 10) / 10,
        max: Math.round(s.max * 10) / 10,
        avg: Math.round(s.avg * 10) / 10,
        count: s.count,
        hours,
      }))
    );
  } catch (error) {
    logger.error({ error }, 'Error fetching sensor stats');
    res.status(500).json({ error: 'Failed to fetch sensor stats' });
  }
});

/**
 * GET /api/sensors/:sensorId
 * Get readings for a specific sensor
 */
router.get('/:sensorId', async (req: Request, res: Response) => {
  try {
    const { limit, from, to } = req.query;
    const filter: Record<string, any> = { sensorId: req.params.sensorId };

    if (from || to) {
      filter.timestamp = {};
      if (from) filter.timestamp.$gte = new Date(from as string);
      if (to) filter.timestamp.$lte = new Date(to as string);
    }

    const readings = await SensorReading.find(filter)
      .sort({ timestamp: -1 })
      .limit(Number(limit) || 50);

    if (readings.length === 0) {
      return res.status(404).json({ error: 'No readings found for this sensor' });
    }

    res.json(readings);
  } catch (error) {
    logger.error({ error, sensorId: req.params.sensorId }, 'Error fetching sensor readings');
    res.status(500).json({ error: 'Failed to fetch sensor readings' });
  }
});

/**
 * POST /api/sensors
 * Store a new sensor reading
 */
router.post('/', async (req: Request, res: Response) => {
  try {
    const { sensorId, sensorName, type, value, unit } = req.body;

    if (!sensorId || !sensorName || !type || value === undefined || !unit) {
      return res.status(400).json({
        error: 'Missing required fields: sensorId, sensorName, type, value, unit',
      });
    }

    const reading = new SensorReading({
      sensorId,
      sensorName,
      type,
      value,
      unit,
      timestamp: req.body.timestamp || new Date(),
    });

    const saved = await reading.save();
    res.status(201).json(saved);
  } catch (error) {
    logger.error({ error }, 'Error saving sensor reading');
    res.status(400).json({ error: 'Failed to save sensor reading' });
  }
});

/**
 * POST /api/sensors/bulk
 * Store multiple readings at once
 */
router.post('/bulk', async (req: Request, res: Response) => {
  try {
    if (!Array.isArray(req.body)) {
      return res.status(400).json({ error: 'Body must be an array of readings' });
    }

    const saved = await SensorReading.insertMany(req.body);
    res.status(201).json({ inserted: saved.length });
  } catch (error) {
    logger.error({ error }, 'Error bulk inserting readings');
    res.status(400).json({ error: 'Failed to bulk insert readings' });
  }
});

/**
 * DELETE /api/sensors/:id
 * Delete a specific reading by MongoDB _id
 */
router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const result = await SensorReading.findByIdAndDelete(req.params.id);
    if (!result) {
      return res.status(404).json({ error: 'Reading not found' });
    }
    res.status(204).send();
  } catch (error) {
    logger.error({ error }, 'Error deleting reading');
    res.status(500).json({ error: 'Failed to delete reading' });
  }
});

export default router;
