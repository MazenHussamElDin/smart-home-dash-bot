import { Router, Request, Response } from 'express';
import { settingsManager } from '../config/settingsManager';
import { logger } from '../utils/logger';

const router = Router();

// ─────────────────────────────────────
//  WEATHER (OpenWeatherMap)
// ─────────────────────────────────────

/**
 * GET /api/external/weather
 * Proxies the OpenWeatherMap API, falls back to mock data
 */
router.get('/weather', async (req: Request, res: Response) => {
  try {
    const general = settingsManager.getAll().general;
    const lat = (req.query.lat as string) || general.weatherLat;
    const lon = (req.query.lon as string) || general.weatherLon;
    const apiKey = process.env.OPENWEATHER_API_KEY || '';

    if (!apiKey) {
      // Mock data for development
      return res.json({
        city: general.weatherCity,
        temperature: Math.round(15 + Math.random() * 10),
        description: 'Partly cloudy',
        humidity: Math.round(50 + Math.random() * 20),
        windSpeed: Math.round(5 + Math.random() * 15),
        icon: '02d',
        feelsLike: Math.round(14 + Math.random() * 10),
        mock: true,
      });
    }

    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric&lang=de`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`OpenWeatherMap responded with ${response.status}`);
    }

    const data: any = await response.json();

    res.json({
      city: data.name,
      temperature: Math.round(data.main.temp),
      description: data.weather[0].description,
      humidity: data.main.humidity,
      windSpeed: Math.round(data.wind.speed * 3.6), // m/s -> km/h
      icon: data.weather[0].icon,
      feelsLike: Math.round(data.main.feels_like),
      mock: false,
    });
  } catch (error) {
    logger.error(`Error fetching weather: %o', ${error}`);
    res.status(500).json({ error: 'Failed to fetch weather data' });
  }
});

// ─────────────────────────────────────
//  MENSA (OpenMensa API)
// ─────────────────────────────────────

/**
 * GET /api/external/mensa
 * Proxies the OpenMensa API
 * Query params: mensaId, date (YYYY-MM-DD)
 */
router.get('/mensa', async (req: Request, res: Response) => {
  try {
    const general = settingsManager.getAll().general;
    const mensaId = (req.query.mensaId as string) || general.mensaId;
    const date =
      (req.query.date as string) || new Date().toISOString().split('T')[0];

    const url = `https://openmensa.org/api/v2/canteens/${mensaId}/days/${date}/meals`;
    const response = await fetch(url);

    if (!response.ok) {
      // Mensa is often closed on weekends or holidays — return mock data
      logger.info('Mensa API returned %d — using mock data', response.status);
      return res.json({
        meals: [
          {
            name: 'Tomatensuppe',
            category: 'Suppe',
            prices: { students: 0.7, employees: 0.9, others: 1.4 },
            notes: ['vegetarisch'],
          },
          {
            name: 'Spaghetti Bolognese',
            category: 'Hauptgericht',
            prices: { students: 2.5, employees: 3.2, others: 4.0 },
            notes: ['mit Rindfleisch'],
          },
          {
            name: 'Gemüsecurry mit Reis',
            category: 'Vegetarisch',
            prices: { students: 2.2, employees: 2.8, others: 3.6 },
            notes: ['vegan', 'mit Soja'],
          },
          {
            name: 'Apfelstrudel mit Vanillesoße',
            category: 'Dessert',
            prices: { students: 1.2, employees: 1.5, others: 2.0 },
            notes: ['vegetarisch', 'Gluten'],
          },
        ],
        date,
        mock: true,
      });
    }

    const meals = await response.json();
    res.json({ meals, date, mock: false });
  } catch (error) {
    logger.error(`Error fetching mensa data: %o, ${error}`);
    res.status(500).json({ error: 'Failed to fetch mensa data' });
  }
});

/**
 * GET /api/external/mensa/canteens
 * Search for canteens near a location
 */
router.get('/mensa/canteens', async (req: Request, res: Response) => {
  try {
    const general = settingsManager.getAll().general;
    const lat = (req.query.lat as string) || general.weatherLat;
    const lng = (req.query.lng as string) || general.weatherLon;
    const dist = (req.query.dist as string) || '15';

    const url = `https://openmensa.org/api/v2/canteens?near[lat]=${lat}&near[lng]=${lng}&near[dist]=${dist}`;
    const response = await fetch(url);
    const canteens = await response.json();

    res.json(canteens);
  } catch (error) {
    logger.error(`Error searching canteens: %o, ${error}`);
    res.status(500).json({ error: 'Failed to search canteens' });
  }
});

// ─────────────────────────────────────
//  SENSOR SIMULATOR
//  Replaces real IoT hardware for dev
// ─────────────────────────────────────

// Keep some state so values look realistic (random walk)
const sensorState: Record<string, number> = {
  temperature: 22.0,
  humidity: 50.0,
  co2: 600.0,
  pressure: 1013.0,
  light: 350.0,
};

function simulateReading(type: string): { value: number; unit: string } {
  const configs: Record<string, { min: number; max: number; step: number; unit: string }> = {
    temperature: { min: 16, max: 30, step: 0.3, unit: '°C' },
    humidity: { min: 25, max: 75, step: 1.5, unit: '%' },
    co2: { min: 350, max: 1200, step: 15, unit: 'ppm' },
    pressure: { min: 990, max: 1035, step: 0.5, unit: 'hPa' },
    light: { min: 0, max: 1000, step: 20, unit: 'lux' },
  };

  const cfg = configs[type] || configs.temperature;
  const current = sensorState[type] ?? (cfg.min + cfg.max) / 2;

  // Random walk: small step in either direction
  const delta = (Math.random() - 0.5) * 2 * cfg.step;
  let next = current + delta;

  // Clamp to valid range
  next = Math.max(cfg.min, Math.min(cfg.max, next));
  sensorState[type] = next;

  return {
    value: Math.round(next * 10) / 10,
    unit: cfg.unit,
  };
}

/**
 * GET /api/external/sensor-simulate
 * Returns a single simulated reading
 * Query params: type (temperature, humidity, co2, pressure, light)
 */
router.get('/sensor-simulate', (req: Request, res: Response) => {
  const type = (req.query.type as string) || 'temperature';
  const reading = simulateReading(type);

  const sensors = settingsManager.getActiveSensors();
  const matchingSensor = sensors.find((s) => s.type === type);

  res.json({
    sensorId: matchingSensor?.id || `sim-${type}`,
    sensorName: matchingSensor?.name || `Simulated ${type}`,
    type,
    value: reading.value,
    unit: reading.unit,
    timestamp: new Date().toISOString(),
  });
});

/**
 * GET /api/external/sensor-simulate/all
 * Returns one simulated reading per active sensor
 */
router.get('/sensor-simulate/all', (_req: Request, res: Response) => {
  const sensors = settingsManager.getActiveSensors();
  const readings = sensors.map((sensor) => {
    const reading = simulateReading(sensor.type);
    return {
      sensorId: sensor.id,
      sensorName: sensor.name,
      type: sensor.type,
      value: reading.value,
      unit: reading.unit,
      timestamp: new Date().toISOString(),
    };
  });

  res.json(readings);
});

export default router;
