import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/stores_auth'

// Lazy-loaded views — each view is a separate chunk
const DashboardView = () => import('@/views/DashboardView.vue')
const SensorsView = () => import('@/views/SensorsView.vue')
const HistoryView = () => import('@/views/HistoryView.vue')
const SettingsView = () => import('@/views/SettingsView.vue')
const UsersView = () => import('@/views/UsersView.vue')
const LoginView = () => import('@/views/LoginView.vue')
const RegisterView = () => import('@/views/RegisterView.vue')

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      redirect: '/dashboard',
    },
    {
      path: '/dashboard',
      name: 'dashboard',
      component: DashboardView,
      meta: { requiresAuth: true, title: 'Dashboard' },
    },
    {
      path: '/sensors',
      name: 'sensors',
      component: SensorsView,
      meta: { requiresAuth: true, title: 'Live Sensors' },
    },
    {
      path: '/history',
      name: 'history',
      component: HistoryView,
      meta: { requiresAuth: true, title: 'History' },
    },
    {
      path: '/settings',
      name: 'settings',
      component: SettingsView,
      meta: { requiresAuth: true, title: 'Settings' },
    },
    {
      path: '/users',
      name: 'users',
      component: UsersView,
      meta: { requiresAuth: true, title: 'Users' },
    },
    {
      path: '/login',
      name: 'login',
      component: LoginView,
      meta: { requiresAuth: false, title: 'Login' },
    },
    {
      path: '/register',
      name: 'register',
      component: RegisterView,
      meta: { requiresAuth: false, title: 'Register' },
    },
    {
      // Catch-all — redirect unknown routes to dashboard
      path: '/:pathMatch(.*)*',
      redirect: '/dashboard',
    },
  ],
})

// ── Navigation guard ──────────────────────────────────
router.beforeEach(async (to) => {
  const auth = useAuthStore()

  // Update page title
  document.title = to.meta.title
    ? `${to.meta.title} — Smart Home Dashboard`
    : 'Smart Home Dashboard'

  // If route requires auth and user is not logged in → redirect to login
  if (to.meta.requiresAuth && !auth.isAuthenticated) {
    return { name: 'login' }
  }

  // If already logged in and trying to reach login/register → redirect to dashboard
  if (!to.meta.requiresAuth && auth.isAuthenticated) {
    return { name: 'dashboard' }
  }
})

export default router
