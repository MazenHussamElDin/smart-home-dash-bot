import SensorReading from '../models/SensorReading';
import { settingsManager, SensorConfig } from '../config/settingsManager';
import { logger } from '../utils/logger';

/**
 * SensorCollector
 *
 * Background service that periodically polls sensors (simulated for dev)
 * and stores readings in MongoDB. Reads config from settings.json on start.
 *
 * This fulfils the requirement:
 *   "The settings JSON file must be read at the beginning to set up the sensor views."
 *   "A dynamic chart with dynamic data (update approx. every second)"
 */

// Random-walk state per sensor
const sensorState: Record<string, number> = {};

function getSimulatedValue(sensor: SensorConfig): number {
  const configs: Record<string, { min: number; max: number; step: number }> = {
    temperature: { min: 16, max: 30, step: 0.3 },
    humidity: { min: 25, max: 75, step: 1.5 },
    co2: { min: 350, max: 1200, step: 15 },
    pressure: { min: 990, max: 1035, step: 0.5 },
    light: { min: 0, max: 1000, step: 20 },
  };

  const cfg = configs[sensor.type] || configs.temperature;

  if (!(sensor.id in sensorState)) {
    sensorState[sensor.id] = (cfg.min + cfg.max) / 2;
  }

  const delta = (Math.random() - 0.5) * 2 * cfg.step;
  let next = sensorState[sensor.id] + delta;
  next = Math.max(cfg.min, Math.min(cfg.max, next));
  sensorState[sensor.id] = next;

  return Math.round(next * 10) / 10;
}

class SensorCollector {
  private intervals: Map<string, NodeJS.Timeout> = new Map();
  private running = false;

  /** Start polling all active sensors based on settings */
  start(): void {
    if (this.running) return;
    this.running = true;

    const sensors = settingsManager.getActiveSensors();
    logger.info('SensorCollector starting with %d active sensors', sensors.length);

    for (const sensor of sensors) {
      this.startPolling(sensor);
    }
  }

  /** Stop all polling */
  stop(): void {
    for (const [id, interval] of this.intervals) {
      clearInterval(interval);
      logger.info('Stopped polling sensor %s', id);
    }
    this.intervals.clear();
    this.running = false;
    logger.info('SensorCollector stopped');
  }

  /** Restart with new settings (call after settings are updated) */
  restart(): void {
    this.stop();
    this.start();
  }

  private startPolling(sensor: SensorConfig): void {
    const interval = setInterval(async () => {
      try {
        const value = getSimulatedValue(sensor);

        const reading = new SensorReading({
          sensorId: sensor.id,
          sensorName: sensor.name,
          type: sensor.type,
          value,
          unit: sensor.unit,
          timestamp: new Date(),
        });

        await reading.save();
      } catch (err) {
        logger.error(`Error saving reading for %s: %o, ${sensor.id}, ${err}`);
      }
    }, sensor.pollingInterval);

    this.intervals.set(sensor.id, interval);
    logger.info(
      'Polling sensor "%s" (%s) every %dms',
      sensor.name,
      sensor.type,
      sensor.pollingInterval
    );
  }
}

// Singleton
export const sensorCollector = new SensorCollector();
