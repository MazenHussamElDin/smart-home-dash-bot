import mongoose, { Schema, Document } from 'mongoose';

export interface ISensorReading extends Document {
  sensorId: string;
  sensorName: string;
  type: string;
  value: number;
  unit: string;
  timestamp: Date;
}

const SensorReadingSchema: Schema = new Schema(
  {
    sensorId: { type: String, required: true, index: true },
    sensorName: { type: String, required: true },
    type: {
      type: String,
      required: true,
      enum: ['temperature', 'humidity', 'co2', 'pressure', 'light'],
    },
    value: { type: Number, required: true },
    unit: { type: String, required: true },
    timestamp: { type: Date, default: Date.now, index: true },
  },
  {
    timestamps: false, // we use our own timestamp field
  }
);

// Compound index for fast queries by sensor + time range
SensorReadingSchema.index({ sensorId: 1, timestamp: -1 });

export default mongoose.model<ISensorReading>('SensorReading', SensorReadingSchema);
