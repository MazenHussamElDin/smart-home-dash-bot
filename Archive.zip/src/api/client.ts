/**
 * API client — thin fetch wrapper used by all API modules.
 * Automatically attaches JWT token from localStorage.
 * Throws on non-2xx responses with the server's error message.
 */

const BASE_URL = '/api'

function getToken(): string | null {
  return localStorage.getItem('token')
}

interface RequestOptions {
  method?: string
  body?: unknown
  skipAuth?: boolean
}

async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = 'GET', body, skipAuth = false } = options

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  }

  if (!skipAuth) {
    const token = getToken()
    if (token) {
      headers['Authorization'] = `Bearer ${token}`
    }
  }

  const response = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  })

  if (!response.ok) {
    let message = `Request failed: ${response.status}`
    try {
      const data = await response.json()
      if (data.error) message = data.error
    } catch {
      // ignore parse errors
    }
    throw new Error(message)
  }

  // 204 No Content — return empty
  if (response.status === 204) {
    return undefined as unknown as T
  }

  return response.json() as Promise<T>
}

export const api = {
  get: <T>(path: string, skipAuth = false) =>
    request<T>(path, { method: 'GET', skipAuth }),

  post: <T>(path: string, body: unknown, skipAuth = false) =>
    request<T>(path, { method: 'POST', body, skipAuth }),

  put: <T>(path: string, body: unknown) =>
    request<T>(path, { method: 'PUT', body }),

  delete: <T>(path: string) =>
    request<T>(path, { method: 'DELETE' }),
}
