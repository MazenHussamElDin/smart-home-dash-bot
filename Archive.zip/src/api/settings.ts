import { api } from './client'

export interface SensorConfig {
  id: string
  name: string
  type: string
  ip: string
  port: number
  pollingInterval: number
  unit: string
  active: boolean
}

export interface GeneralSettings {
  dashboardTitle: string
  refreshRate: number
  theme: string
  mensaId: string
  weatherLat: string
  weatherLon: string
  weatherCity: string
}

export interface AppSettings {
  sensors: SensorConfig[]
  general: GeneralSettings
}

export interface ReachabilityResult {
  reachable: boolean
  latencyMs: number
  status?: number
  error?: string
}

export const settingsApi = {
  getAll: () => api.get<AppSettings>('/settings'),

  updateAll: (settings: AppSettings) => api.put<{ message: string; settings: AppSettings }>('/settings', settings),

  updateGeneral: (general: GeneralSettings) =>
    api.put<{ message: string; settings: AppSettings }>('/settings/general', general),

  updateSensors: (sensors: SensorConfig[]) =>
    api.put<{ message: string; settings: AppSettings }>('/settings/sensors', sensors),

  testReachability: (ip: string, port: number, path?: string) =>
    api.post<ReachabilityResult>('/settings/sensors/test', { ip, port, path }),
}
