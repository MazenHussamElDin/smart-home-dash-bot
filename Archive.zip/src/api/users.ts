import { api } from './client'

export interface User {
  _id: string
  firstName: string
  lastName: string
  email: string
  role: string
  department: string
  notes: string
  createdAt: string
}

export interface CreateUserPayload {
  firstName: string
  lastName: string
  email: string
  role?: string
  department?: string
  notes?: string
}

export const usersApi = {
  getAll: () => api.get<User[]>('/users'),

  create: (payload: CreateUserPayload) => api.post<User>('/users', payload),

  update: (id: string, payload: Partial<CreateUserPayload>) =>
    api.put<User>(`/users/${id}`, payload),

  delete: (id: string) => api.delete<void>(`/users/${id}`),
}
