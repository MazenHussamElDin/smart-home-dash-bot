import { api } from './client'

export interface SensorReading {
  _id: string
  sensorId: string
  sensorName: string
  type: string
  value: number
  unit: string
  timestamp: string
}

export interface SensorStats {
  sensorId: string
  type: string
  sensorName: string
  unit: string
  min: number
  max: number
  avg: number
  count: number
  hours: number
}

export interface SystemReading {
  sensorId: string
  sensorName: string
  type: string
  value: number
  unit: string
}

export interface SystemAllResponse {
  timestamp: string
  real: boolean
  readings: SystemReading[]
}

export const sensorsApi = {
  getLatest: () => api.get<SensorReading[]>('/sensors/latest'),

  getReadings: (params: {
    sensorId?: string
    type?: string
    limit?: number
    from?: string
    to?: string
  }) => {
    const q = new URLSearchParams()
    if (params.sensorId) q.set('sensorId', params.sensorId)
    if (params.type) q.set('type', params.type)
    if (params.limit) q.set('limit', String(params.limit))
    if (params.from) q.set('from', params.from)
    if (params.to) q.set('to', params.to)
    return api.get<SensorReading[]>(`/sensors?${q.toString()}`)
  },

  getStats: (hours = 24, sensorId?: string) => {
    const q = new URLSearchParams({ hours: String(hours) })
    if (sensorId) q.set('sensorId', sensorId)
    return api.get<SensorStats[]>(`/sensors/stats?${q.toString()}`)
  },

  getSystemAll: () => api.get<SystemAllResponse>('/system/all'),

  getSystemInfo: () => api.get<{
    os: { platform: string; distro: string; hostname: string }
    cpu: { currentLoad: number; cores: number }
    memory: { total: number; used: number; free: number; usedPercent: number }
    uptime: number
    timestamp: string
  }>('/system/info'),
}
