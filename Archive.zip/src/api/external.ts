import { api } from './client'

export interface WeatherData {
  city: string
  temperature: number
  description: string
  humidity: number
  windSpeed: number
  icon: string
  feelsLike: number
  mock: boolean
}

export interface MensaMeal {
  name: string
  category: string
  prices: { students: number; employees: number; others: number }
  notes: string[]
}

export interface MensaResponse {
  meals: MensaMeal[]
  date: string
  mock: boolean
}

export const externalApi = {
  getWeather: () => api.get<WeatherData>('/external/weather'),

  getMensa: (date?: string) => {
    const q = date ? `?date=${date}` : ''
    return api.get<MensaResponse>(`/external/mensa${q}`)
  },
}
