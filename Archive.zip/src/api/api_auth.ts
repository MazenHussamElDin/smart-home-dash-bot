import { api } from './client'

export interface AuthUser {
  id: string
  username: string
  email: string
  role: string
}

export interface AuthResponse {
  message: string
  token: string
  user: AuthUser
}

export const authApi = {
  login: (email: string, password: string) =>
    api.post<AuthResponse>('/auth/login', { email, password }, true),

  register: (username: string, email: string, password: string) =>
    api.post<AuthResponse>('/auth/register', { username, email, password }, true),

  me: () => api.get<AuthUser>('/auth/me'),
}
