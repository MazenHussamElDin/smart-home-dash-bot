import fs from 'fs';
import path from 'path';
import { logger } from '../utils/logger';

const SETTINGS_FILE = path.join(__dirname, '../../settings.json');

export interface SensorConfig {
  id: string;
  name: string;
  type: string;
  ip: string;
  port: number;
  pollingInterval: number;
  unit: string;
  active: boolean;
}

export interface AppSettings {
  sensors: SensorConfig[];
  general: {
    dashboardTitle: string;
    refreshRate: number;
    theme: string;
    mensaId: string;
    weatherLat: string;
    weatherLon: string;
    weatherCity: string;
  };
}

const defaultSettings: AppSettings = {
  sensors: [
    {
      id: 'sensor-temp-1',
      name: 'Living Room Temperature',
      type: 'temperature',
      ip: '192.168.1.100',
      port: 8080,
      pollingInterval: 5000,
      unit: '°C',
      active: true,
    },
    {
      id: 'sensor-hum-1',
      name: 'Living Room Humidity',
      type: 'humidity',
      ip: '192.168.1.101',
      port: 8080,
      pollingInterval: 5000,
      unit: '%',
      active: true,
    },
    {
      id: 'sensor-co2-1',
      name: 'Office CO2',
      type: 'co2',
      ip: '192.168.1.102',
      port: 8080,
      pollingInterval: 10000,
      unit: 'ppm',
      active: true,
    },
    {
      id: 'sensor-temp-2',
      name: 'Bedroom Temperature',
      type: 'temperature',
      ip: '192.168.1.103',
      port: 8080,
      pollingInterval: 5000,
      unit: '°C',
      active: true,
    },
  ],
  general: {
    dashboardTitle: 'Smart Home Dashboard',
    refreshRate: 5000,
    theme: 'light',
    mensaId: '187',
    weatherLat: '48.8317',
    weatherLon: '12.9583',
    weatherCity: 'Deggendorf',
  },
};

class SettingsManager {
  private settings: AppSettings;

  constructor() {
    this.settings = this.load();
  }

  /** Read settings from disk, or create with defaults if missing */
  private load(): AppSettings {
    try {
      if (fs.existsSync(SETTINGS_FILE)) {
        const raw = fs.readFileSync(SETTINGS_FILE, 'utf-8');
        const parsed = JSON.parse(raw) as AppSettings;
        logger.info('Settings loaded from settings.json');
        return parsed;
      }
    } catch (err) {
        logger.error(`Error reading settings.json, using defaults: ${err}`);
    }

    // File does not exist or was invalid — write defaults
    this.save(defaultSettings);
    logger.info('Settings file created with defaults');
    return { ...defaultSettings };
  }

  /** Persist current settings to disk */
  private save(data: AppSettings): void {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(data, null, 2), 'utf-8');
  }

  /** Get the full settings object */
  getAll(): AppSettings {
    return this.settings;
  }

  /** Get only the active sensor configs */
  getActiveSensors(): SensorConfig[] {
    return this.settings.sensors.filter((s) => s.active);
  }

  /** Replace the entire settings object */
  update(newSettings: AppSettings): AppSettings {
    this.settings = newSettings;
    this.save(newSettings);
    logger.info('Settings updated and saved');
    return this.settings;
  }

  /** Update just the general section */
  updateGeneral(general: AppSettings['general']): AppSettings {
    this.settings.general = general;
    this.save(this.settings);
    return this.settings;
  }

  /** Update just the sensors list */
  updateSensors(sensors: SensorConfig[]): AppSettings {
    this.settings.sensors = sensors;
    this.save(this.settings);
    return this.settings;
  }
}

// Singleton — imported once, used everywhere
export const settingsManager = new SettingsManager();
