import mongoose from 'mongoose';
import * as dotenv from 'dotenv';
import SensorReading from './models/SensorReading';
import User from './models/User';
import { logger } from './utils/logger';

dotenv.config();

const MONGODB_URI =
  process.env.MONGODB_URI || 'mongodb://localhost:27017/smarthome';

/**
 * Seed script: populates MongoDB with realistic demo data.
 * Run with:  npm run seed
 */
async function seed() {
  await mongoose.connect(MONGODB_URI);
  logger.info('Connected to MongoDB for seeding');

  // ── Clear existing data ──
  await SensorReading.deleteMany({});
  await User.deleteMany({});
  logger.info('Cleared existing data');

  // ── Generate 24h of sensor readings (one per hour per sensor) ──
  const now = Date.now();
  const sensors = [
    { sensorId: 'sensor-temp-1', sensorName: 'Living Room Temperature', type: 'temperature', unit: '°C', base: 22, variance: 3 },
    { sensorId: 'sensor-hum-1', sensorName: 'Living Room Humidity', type: 'humidity', unit: '%', base: 50, variance: 10 },
    { sensorId: 'sensor-co2-1', sensorName: 'Office CO2', type: 'co2', unit: 'ppm', base: 600, variance: 200 },
    { sensorId: 'sensor-temp-2', sensorName: 'Bedroom Temperature', type: 'temperature', unit: '°C', base: 20, variance: 2 },
  ];

  const readings: any[] = [];
  for (const sensor of sensors) {
    let value = sensor.base;
    for (let h = 48; h >= 0; h--) {
      // Random walk
      value += (Math.random() - 0.5) * sensor.variance * 0.3;
      value = Math.max(sensor.base - sensor.variance, Math.min(sensor.base + sensor.variance, value));

      readings.push({
        sensorId: sensor.sensorId,
        sensorName: sensor.sensorName,
        type: sensor.type,
        value: Math.round(value * 10) / 10,
        unit: sensor.unit,
        timestamp: new Date(now - h * 60 * 60 * 1000),
      });
    }
  }

  await SensorReading.insertMany(readings);
  logger.info('Inserted %d sensor readings (48h history for %d sensors)', readings.length, sensors.length);

  // ── Seed users ──
  const users = [
    { firstName: 'Markus', lastName: 'Weber', email: 'markus.weber@th-deg.de', role: 'admin', department: 'Computer Science', notes: 'Primary persona — professor' },
    { firstName: 'Lisa', lastName: 'Meier', email: 'lisa.meier@example.com', role: 'viewer', department: 'IoT Enthusiast', notes: 'Secondary persona — smart home user' },
    { firstName: 'Mazen', lastName: 'Ramadan', email: 'mazen.ramadan@stud.th-deg.de', role: 'admin', department: 'DIT', notes: 'Developer' },
  ];

  await User.insertMany(users);
  logger.info('Inserted %d users', users.length);

  // ── Done ──
  await mongoose.connection.close();
  logger.info('Seed complete. Database connection closed.');
  process.exit(0);
}

seed().catch((err) => {
  logger.error('Seed failed: %o', err);
  process.exit(1);
});
