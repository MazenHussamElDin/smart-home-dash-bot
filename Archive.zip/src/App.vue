<template>
  <div id="app-root">
    <NavBar v-if="auth.isAuthenticated" />
    <main :class="auth.isAuthenticated ? 'main-content' : ''">
      <router-view v-slot="{ Component, route }">
        <transition name="fade" mode="out-in">
          <component :is="Component" :key="route.path" />
        </transition>
      </router-view>
    </main>
  </div>
</template>

<script setup lang="ts">
import { onMounted } from 'vue'
import { useAuthStore } from '@/stores/stores_auth'
import NavBar from '@/components/NavBar.vue'

const auth = useAuthStore()

onMounted(async () => {
  await auth.fetchCurrentUser()
})
</script>

<style>
/* ── THD Corporate Identity tokens ───────────────────── */
:root {
  --thd-charcoal:   #3d3d3d;
  --thd-cyan:       #29abe2;
  --thd-cyan-dark:  #1a95cc;
  --thd-white:      #ffffff;
  --thd-page:       #f7f7f7;
  --thd-border:     #e4e4e4;
  --thd-border-light: #eeeeee;
  --thd-text:       #1a1a1a;
  --thd-muted:      #888888;
  --thd-danger:     #dc3545;
  --thd-success:    #3daa5c;
  --nav-height:     64px;
}

*,
*::before,
*::after {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  background-color: var(--thd-page);
  color: var(--thd-text);
  font-size: 0.95rem;
}

.main-content {
  padding-top: var(--nav-height);
  min-height: 100vh;
}

/* ── Route transition ─────────────────────────────────── */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.15s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

/* ── Shared THD card ─────────────────────────────────── */
.thd-card {
  background: var(--thd-white);
  border: 1px solid var(--thd-border);
  border-radius: 4px;
}

/* ── THD button ──────────────────────────────────────── */
.btn-thd {
  background-color: var(--thd-cyan);
  border: none;
  color: #fff;
  font-weight: 500;
  padding: 0.5rem 1.25rem;
  border-radius: 3px;
  cursor: pointer;
  font-size: 0.875rem;
  transition: background 0.15s;
}
.btn-thd:hover {
  background-color: var(--thd-cyan-dark);
  color: #fff;
}
.btn-thd-outline {
  background: transparent;
  border: 1px solid var(--thd-cyan);
  color: var(--thd-cyan);
  font-weight: 500;
  padding: 0.5rem 1.25rem;
  border-radius: 3px;
  cursor: pointer;
  font-size: 0.875rem;
  transition: background 0.15s, color 0.15s;
}
.btn-thd-outline:hover {
  background: var(--thd-cyan);
  color: #fff;
}

/* ── THD section heading ─────────────────────────────── */
.thd-section-label {
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--thd-muted);
  margin-bottom: 1rem;
}

/* ── THD page heading ────────────────────────────────── */
.thd-page-title {
  font-size: clamp(1.1rem, 3vw, 1.6rem);
  font-weight: 300;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  color: var(--thd-text);
}
</style>
