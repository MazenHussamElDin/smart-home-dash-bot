<template>
  <nav class="thd-navbar fixed-top">
    <div class="thd-navbar-inner container-fluid px-4 h-100 d-flex align-items-center justify-content-between">

      <!-- Brand / Logo -->
      <router-link class="thd-brand text-decoration-none" to="/dashboard">
        <div class="thd-logo">
          <div class="thd-logo-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
            </svg>
          </div>
          <div class="thd-logo-text">
            <span class="thd-logo-line1">SMART HOME</span>
            <span class="thd-logo-line2">DASHBOARD</span>
          </div>
        </div>
      </router-link>

      <!-- Desktop nav links -->
      <ul class="thd-nav-links d-none d-md-flex align-items-center list-unstyled mb-0 gap-0">
        <li v-for="link in navLinks" :key="link.to">
          <router-link
            class="thd-nav-link"
            :to="link.to"
            :class="{ active: route.name === link.name }"
          >
            {{ link.label }}
          </router-link>
        </li>
      </ul>

      <!-- Right: user info + logout + mobile toggle -->
      <div class="d-flex align-items-center gap-3">
        <div class="thd-user-info d-none d-md-flex flex-column align-items-end">
          <span class="thd-username">{{ auth.username }}</span>
          <span class="thd-logout-link" @click="handleLogout">Logout</span>
        </div>
        <!-- Mobile hamburger -->
        <button
          class="thd-hamburger d-md-none"
          @click="mobileOpen = !mobileOpen"
          :aria-expanded="mobileOpen"
          aria-label="Navigation öffnen"
        >
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>

    <!-- Mobile menu -->
    <div class="thd-mobile-menu" :class="{ open: mobileOpen }">
      <router-link
        v-for="link in navLinks"
        :key="link.to"
        class="thd-mobile-link"
        :to="link.to"
        :class="{ active: route.name === link.name }"
        @click="mobileOpen = false"
      >
        {{ link.label }}
      </router-link>
      <button class="thd-mobile-logout" @click="handleLogout">Logout</button>
    </div>
  </nav>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/stores_auth'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const mobileOpen = ref(false)

const navLinks = [
  { to: '/dashboard', name: 'dashboard', label: 'Dashboard' },
  { to: '/sensors',   name: 'sensors',   label: 'Live Sensors' },
  { to: '/history',   name: 'history',   label: 'History' },
  { to: '/settings',  name: 'settings',  label: 'Settings' },
  { to: '/users',     name: 'users',     label: 'Users' },
]

function handleLogout() {
  mobileOpen.value = false
  auth.logout()
  router.push('/login')
}
</script>

<style scoped>
/* ── Navbar shell ─────────────────────────────────────── */
.thd-navbar {
  height: var(--nav-height);
  background-color: var(--thd-charcoal);
  z-index: 1000;
  box-shadow: 0 1px 0 rgba(255,255,255,0.06);
}

/* ── Logo block ───────────────────────────────────────── */
.thd-brand { color: #fff; }

.thd-logo {
  display: flex;
  align-items: center;
  gap: 10px;
}

.thd-logo-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  border: 2px solid #fff;
  color: #fff;
  flex-shrink: 0;
}

.thd-logo-text {
  display: flex;
  flex-direction: column;
  line-height: 1;
  gap: 2px;
}

.thd-logo-line1 {
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.18em;
  color: #fff;
}

.thd-logo-line2 {
  font-size: 0.55rem;
  font-weight: 400;
  letter-spacing: 0.18em;
  color: rgba(255,255,255,0.65);
}

/* ── Nav links ────────────────────────────────────────── */
.thd-nav-link {
  display: block;
  padding: 0.25rem 1rem;
  color: rgba(255,255,255,0.7);
  text-decoration: none;
  font-size: 0.78rem;
  font-weight: 500;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  border-bottom: 2px solid transparent;
  transition: color 0.15s, border-color 0.15s;
  line-height: var(--nav-height);
  height: var(--nav-height);
  display: flex;
  align-items: center;
}

.thd-nav-link:hover {
  color: #fff;
}

.thd-nav-link.active {
  color: #fff;
  border-bottom-color: var(--thd-cyan);
}

/* ── User info (top-right like THD) ──────────────────── */
.thd-user-info {
  line-height: 1.2;
}

.thd-username {
  font-size: 0.8rem;
  color: rgba(255,255,255,0.9);
  font-weight: 500;
}

.thd-logout-link {
  font-size: 0.72rem;
  color: var(--thd-cyan);
  cursor: pointer;
  text-decoration: none;
  transition: color 0.15s;
}

.thd-logout-link:hover {
  color: #fff;
  text-decoration: underline;
}

/* ── Hamburger ────────────────────────────────────────── */
.thd-hamburger {
  background: transparent;
  border: none;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  gap: 5px;
  padding: 4px;
}
.thd-hamburger span {
  display: block;
  width: 22px;
  height: 2px;
  background: rgba(255,255,255,0.8);
  border-radius: 1px;
}

/* ── Mobile menu ──────────────────────────────────────── */
.thd-mobile-menu {
  display: none;
  flex-direction: column;
  background: var(--thd-charcoal);
  border-top: 1px solid rgba(255,255,255,0.08);
}
.thd-mobile-menu.open { display: flex; }

.thd-mobile-link {
  display: block;
  padding: 0.75rem 1.5rem;
  color: rgba(255,255,255,0.75);
  text-decoration: none;
  font-size: 0.85rem;
  font-weight: 500;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  border-bottom: 1px solid rgba(255,255,255,0.06);
  transition: background 0.15s;
}
.thd-mobile-link:hover,
.thd-mobile-link.active {
  background: rgba(255,255,255,0.06);
  color: #fff;
}

.thd-mobile-logout {
  background: none;
  border: none;
  padding: 0.75rem 1.5rem;
  color: var(--thd-cyan);
  font-size: 0.85rem;
  font-weight: 500;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  text-align: left;
  cursor: pointer;
}
</style>
