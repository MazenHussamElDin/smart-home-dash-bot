import express, { Request, Response, NextFunction, ErrorRequestHandler } from 'express';
import cors from 'cors';
import * as dotenv from 'dotenv';
import mongoose from 'mongoose';
import rateLimit from 'express-rate-limit';

import { logger } from './utils/logger';
import { settingsManager } from './config/settingsManager';
import { sensorCollector } from './services/sensorCollector';

// Routes
import sensorRoutes from './routes/sensorRoutes';
import userRoutes from './routes/userRoutes';
import settingsRoutes from './routes/settingsRoutes';
import externalRoutes from './routes/externalRoutes';
import authRoutes from './routes/authRoutes';
import systemRoutes from './routes/systemRoutes';

// ── Bootstrap ──────────────────────────────────────────
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// ── Rate Limiting ───────────────────────────────────────
// General limiter: 200 requests per 15 minutes per IP
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, please try again later.' },
});

// Stricter limiter for auth routes: 20 requests per 15 minutes
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many authentication attempts, please try again later.' },
});

// ── Middleware ──────────────────────────────────────────

// CORS — allow the Vue frontend
app.use(
  cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
    credentials: true,
  })
);

// Apply general rate limiter to all routes
app.use(generalLimiter);

// Body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logger
app.use((req: Request, _res: Response, next: NextFunction) => {
  logger.info(`${req.method} ${req.url}`);
  next();
});

// ── API Routes ─────────────────────────────────────────
// Auth routes with stricter rate limit
app.use('/api/auth', authLimiter, authRoutes);

// API routes
app.use('/api/sensors', sensorRoutes);
app.use('/api/users', userRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/external', externalRoutes);
app.use('/api/system', systemRoutes);

// ── Root — API overview ────────────────────────────────
app.get('/', (_req: Request, res: Response) => {
  const settings = settingsManager.getAll();
  res.json({
    name: settings.general.dashboardTitle,
    version: '1.0.0',
    endpoints: {
      auth: {
        register: 'POST /api/auth/register',
        login: 'POST /api/auth/login',
        me: 'GET  /api/auth/me (protected)',
      },
      sensors: {
        list: 'GET  /api/sensors',
        latest: 'GET  /api/sensors/latest',
        stats: 'GET  /api/sensors/stats',
        byId: 'GET  /api/sensors/:sensorId',
        create: 'POST /api/sensors',
        bulk: 'POST /api/sensors/bulk',
        delete: 'DEL  /api/sensors/:id',
      },
      users: {
        list: 'GET  /api/users',
        byId: 'GET  /api/users/:id',
        create: 'POST /api/users',
        update: 'PUT  /api/users/:id',
        delete: 'DEL  /api/users/:id',
      },
      settings: {
        get: 'GET  /api/settings',
        update: 'PUT  /api/settings',
        sensors: 'GET  /api/settings/sensors',
        updateSensors: 'PUT  /api/settings/sensors',
        updateGeneral: 'PUT  /api/settings/general',
        reachability: 'POST /api/settings/sensors/test',
      },
      external: {
        weather: 'GET  /api/external/weather',
        mensa: 'GET  /api/external/mensa',
        mensaCanteens: 'GET  /api/external/mensa/canteens',
        sensorSim: 'GET  /api/external/sensor-simulate',
        sensorSimAll: 'GET  /api/external/sensor-simulate/all',
      },
      system: {
        info: 'GET  /api/system/info',
        cpu: 'GET  /api/system/cpu (real sensor data)',
        memory: 'GET  /api/system/memory (real sensor data)',
        disk: 'GET  /api/system/disk (real sensor data)',
        network: 'GET  /api/system/network (real sensor data)',
        all: 'GET  /api/system/all (all real sensors at once)',
      },
    },
  });
});

// ── 404 handler ────────────────────────────────────────
app.use((_req: Request, res: Response) => {
  res.status(404).json({ error: 'Route not found' });
});

// ── Error handler (must be last) ───────────────────────
const errorHandler: ErrorRequestHandler = (err, _req, res, _next) => {
  logger.error(`Unhandled error: ${err}`);
  res.status(500).json({ error: 'Internal server error' });
};
app.use(errorHandler);

// ── Database + Start ───────────────────────────────────
const MONGODB_URI =
  process.env.MONGODB_URI || 'mongodb://localhost:27017/smarthome';

mongoose
  .connect(MONGODB_URI)
  .then(() => {
    logger.info(`Connected to MongoDB at ${MONGODB_URI}`);

    // Start background sensor data collector
    sensorCollector.start();

    app.listen(PORT, () => {
      logger.info(`Server running on http://localhost:${PORT}`);
      logger.info(`Frontend expected at ${process.env.FRONTEND_URL || 'http://localhost:5173'}`);
    });
  })
  .catch((error) => {
    logger.error(`MongoDB connection failed: ${error}`);
    logger.info('Starting server without database...');

    app.listen(PORT, () => {
      logger.info(`Server running on http://localhost:${PORT} (no DB)`);
    });
  });

// Graceful shutdown
process.on('SIGINT', () => {
  logger.info('Shutting down...');
  sensorCollector.stop();
  mongoose.connection.close();
  process.exit(0);
});

export default app;
